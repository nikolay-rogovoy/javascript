/***/
export interface IAuthUser {
    /***/
    iduser: number;
    /***/
    user_name: string;
    /***/
    login: string;
    /***/
    password: string;
}
