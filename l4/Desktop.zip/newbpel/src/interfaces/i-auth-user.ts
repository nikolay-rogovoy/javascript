/***/
export interface IAuthUser {
    /***/
    iduser: number;
    /***/
    idorg: number;
    /***/
    user_name: string;
    /***/
    password: string;
}
