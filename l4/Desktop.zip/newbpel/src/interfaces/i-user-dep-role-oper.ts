/***/
export interface IUserDepRoleOper {
    /***/
    idoperation: number;
    /***/
    name: string;
}
