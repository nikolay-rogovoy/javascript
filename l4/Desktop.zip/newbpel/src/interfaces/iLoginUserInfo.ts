/***/
export interface ILoginUserInfo {
    /***/
    iduser: number,
    /***/
    idorg: number,
    /***/
    user_name: string
}
