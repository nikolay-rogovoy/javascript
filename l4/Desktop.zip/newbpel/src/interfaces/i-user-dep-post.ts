/***/
export interface IUserDepPost {
    /***/
    idpost: number;
    /***/
    name: string;
}
