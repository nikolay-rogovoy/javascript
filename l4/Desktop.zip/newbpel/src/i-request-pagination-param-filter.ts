/***/
export interface IRequestPaginationParamFilter {
    /***/
    fieldName: string;
    /***/
    value: string;
}
