export interface CmmsWoSum {
    attribute1: string;
    department: string;
    wip_accounting_class: string;
    contract_line: string;
    description: string;
    activity: string;
    qty: string;
    unit_rate: string;
}
