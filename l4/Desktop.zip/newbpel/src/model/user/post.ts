export interface Post {
    idpost: number;
    name: string;
}
