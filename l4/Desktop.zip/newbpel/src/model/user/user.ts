export interface User {
    iduser: number;
    name: string;
    login: string;
    pass: string;
}
