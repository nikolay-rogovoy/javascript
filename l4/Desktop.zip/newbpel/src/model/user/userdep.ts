export interface Userdep {
    iduserdep: number;
    iduser: number;
    iddep: number;
    idpost: number;
}
