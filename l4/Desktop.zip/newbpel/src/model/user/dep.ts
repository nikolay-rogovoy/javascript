export interface Dep {
    iddep: number;
    name: string;
}
