/***/
export interface IRequestParam {
    /***/
    param: any;
    /***/
    iddep: number;
    /***/
    dep_name: string;
}
