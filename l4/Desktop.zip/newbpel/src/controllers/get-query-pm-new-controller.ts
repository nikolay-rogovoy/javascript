import { Request, Response, Query, ParamsDictionary } from 'express-serve-static-core';
import { Auth } from '../auth';
import { CommonLib } from '../common-lib';
import { getLogger } from '../libs/logger';
import { BaseAuthController } from './base-auth-controller';
import { switchMap, map } from 'rxjs/operators';
import { _throw } from 'rxjs/observable/throw';
import { of } from 'rxjs/observable/of';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { IRequestPaginationParam } from '../i-request-pagination-param';

/***/
export class GetQueryPmNewController extends BaseAuthController {

    /***/
    static logger = getLogger(module);

    /***/
    auth = new Auth();

    /***/
    constructor() {
        super();
    }

    /***/
    async handler(req: Request<Param, any, any, IPaginationParam>, res: Response) {
        const logId = this.getLogId();
        GetQueryPmNewController.logger.debug(CommonLib.getLogString(logId, `handleRoutes get query pm new`));

        let paginationParam = req.query.paginationParam ? <IRequestPaginationParam>JSON.parse(req.query.paginationParam) : null;
        let query = `
SELECT a.AREA,
        a.SERIAL_NUMBER,
        A.DESCRIPTIVE_TEXT,
        PMS.ACCOUNTING_CLASS_CODE, 
        A.OWNING_DEPARTMENT, 
        NET.NETWORK_SERIAL_NUMBER ,
        PMS.NAME, 
        PMS.DAY_INTERVAL*PMS.INTERVAL_MULTIPLE AS INTERVAL_DAY, 
        PMS.CONCATENATED_SEGMENTS AS PLAN_NUM, 
        PMS.ACTIVITY_DESCRIPTION, 
        PMS.LAST_SERVICE_START_DATE, 
        (PMS.DAY_INTERVAL*PMS.INTERVAL_MULTIPLE)+ PMS.LAST_SERVICE_START_DATE as ESTIM_NEXT_DATE,  
        F.NEXT_DATE
FROM MTL_EAM_ASSET_NUMBERS_V A
      left JOIN (select * from MTL_EAM_NETWORK_ASSETS where END_DATE_ACTIVE is null)  NET 
           ON A.SERIAL_NUMBER = NET.SERIAL_NUMBER
      left join (SELECT PM.MAINTENANCE_OBJECT_ID,
                        PM.PM_SCHEDULE_ID, 
                        PM.NAME, 
                        PM.ASSET_NUMBER, 
                        PMR.DAY_INTERVAL, 
                        PMAG.CONCATENATED_SEGMENTS , 
                        PMAG.INTERVAL_MULTIPLE , 
                        MEAA.ACTIVITY_DESCRIPTION, 
                        MEAA.ACCOUNTING_CLASS_CODE, 
                        MEAA.LAST_SERVICE_START_DATE, 
                        PMAG.ACTIVITY_ASSOCIATION_ID
                   FROM EAM_PM_SCHEDULINGS_V  PM
                     LEFT JOIN EAM_PM_SCHEDULING_RULES PMR ON PM.PM_SCHEDULE_ID = PMR.PM_SCHEDULE_ID
                     LEFT JOIN EAM_PM_ACTIVITYGROUP_V PMAG ON PM.PM_SCHEDULE_ID = PMAG.PM_SCHEDULE_ID
                     LEFT JOIN MTL_EAM_ASSET_ACTIVITIES_V MEAA ON PMAG.ACTIVITY_ASSOCIATION_ID = MEAA.ACTIVITY_ASSOCIATION_ID
                 WHERE PM.SET_NAME = 'LUK' 
                     AND PM.TO_EFFECTIVE_DATE IS NULL) PMS
       ON PMS.MAINTENANCE_OBJECT_ID = nvl( NET.NETWORK_OBJECT_ID, A.MAINTENANCE_OBJECT_ID)
       LEFT JOIN (select FR.PM_SCHEDULE_ID, 
                         FR.ACTIVITY_ASSOCIATION_ID , 
                         min(to_date(FR.SCHEDULED_START_DATE,'DD-MON-YYYY')) next_date  
                  from eam_forecasted_work_orders fr 
                 group by FR.PM_SCHEDULE_ID, 
                          FR.ACTIVITY_ASSOCIATION_ID) F 
       ON F.ACTIVITY_ASSOCIATION_ID = PMS.ACTIVITY_ASSOCIATION_ID AND F.PM_SCHEDULE_ID = PMS.PM_SCHEDULE_ID
WHERE A.EAM_ITEM_TYPE = 1
`;
        GetQueryPmNewController.logger.debug(query);
        CommonLib.select(query)
            .pipe(
                map((data: any[]) => {
                    GetQueryPmNewController.logger.debug(`data.length = ${data.length}`);
                    return data.map(row => {
                        return {
                            ... row,
                        }
                    });
                }),
                switchMap((entities: any[]) => {
                    return forkJoin(
                        of(entities.length),
                        of(entities));
                }),
            ).subscribe(
                (entitysToGetAndCount: [number, any[]]) => {
                    res.json({
                        message: 'Successful',
                        result: {
                            data: entitysToGetAndCount[1],
                            count: entitysToGetAndCount[0],
                            limit: paginationParam ? paginationParam.limit : null,
                            offset: paginationParam ? paginationParam.offset : null
                        }
                    });
                    GetQueryPmNewController.logger.debug(CommonLib.getLogString(logId, { result: `Successful`, length: entitysToGetAndCount[1].length }));
                },
                (error) => {
                    let errorMessage = `Error: ${error.message}`;
                    GetQueryPmNewController.logger.error(CommonLib.getLogString(logId, { error: errorMessage }));
                    res.status(500);
                    res.json({ message: errorMessage });
                });
    }
}

/***/
export interface IPaginationParam extends Query {
    paginationParam: string;
}


/***/
interface Param extends ParamsDictionary {
    dt_start: string;
    dt_end: string;
}
