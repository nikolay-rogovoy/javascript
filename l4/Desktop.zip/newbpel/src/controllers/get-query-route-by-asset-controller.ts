import { Request, Response, Query, ParamsDictionary } from 'express-serve-static-core';
import { Auth } from '../auth';
import { CommonLib } from '../common-lib';
import { getLogger } from '../libs/logger';
import { BaseAuthController } from './base-auth-controller';
import { switchMap, map } from 'rxjs/operators';
import { _throw } from 'rxjs/observable/throw';
import { of } from 'rxjs/observable/of';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { IRequestPaginationParam } from '../i-request-pagination-param';

/***/
export class GetQueryRouteByAssetController extends BaseAuthController {

    /***/
    static logger = getLogger(module);

    /***/
    auth = new Auth();

    /***/
    constructor() {
        super();
    }

    /***/
    async handler(req: Request<Param, any, any, IPaginationParam>, res: Response) {
        const logId = this.getLogId();
        GetQueryRouteByAssetController.logger.debug(CommonLib.getLogString(logId, `handleRoutes get asset by route ${req.params.name}`));

        let paginationParam = req.query.paginationParam ? <IRequestPaginationParam>JSON.parse(req.query.paginationParam) : null;
        let query = `
        select
        csi_route.instance_id as "Route_ID",
        csi_route.instance_number as "Route_Number",
        na.start_date_active as "Start_Date",
        na.end_date_active as "End_Date",
        csi_asset.instance_id as "Asset_ID",
        csi_asset.instance_number as "Asset_Number"
        from csi_item_instances csi_route
          left join mtl_eam_network_assets na on csi_route.instance_id=na.network_object_id
          left join csi_item_instances csi_asset on na.maintenance_object_id = csi_asset.instance_id
        where csi_asset.instance_number='${req.params.name}'`;
        /*
        Route_ID,
        Route_Number,
        Start_Date,
        End_Date,
        Asset_ID,
        Asset_Number
        */
        GetQueryRouteByAssetController.logger.debug(query);
        CommonLib.select(query)
            .pipe(
                map((data: any[]) => {
                    GetQueryRouteByAssetController.logger.debug(`data.length = ${data.length}`);
                    return data.map(row => {
                        return {
                            Route_ID: row['Route_ID'],
                            Route_Number: row['Route_Number'],
                            Start_Date: row['Start_Date'],
                            End_Date: row['End_Date'],
                            // Start_Date: row['Start_Date'] ? CommonLib.parseOracleDate(row['Start_Date']): null,
                            // End_Date: row['End_Date'] ? CommonLib.parseOracleDate(row['End_Date']) : null,
                            Asset_ID: row['Asset_ID'],
                            Asset_Number: row['Asset_Number'],
                        }
                    });
                }),
                switchMap((entities: any[]) => {
                    return forkJoin(
                        of(entities.length),
                        of(entities));
                }),
            ).subscribe(
                (entitysToGetAndCount: [number, any[]]) => {
                    res.json({
                        message: 'Successful',
                        result: {
                            data: entitysToGetAndCount[1],
                            count: entitysToGetAndCount[0],
                            limit: paginationParam ? paginationParam.limit : null,
                            offset: paginationParam ? paginationParam.offset : null
                        }
                    });
                    GetQueryRouteByAssetController.logger.debug(CommonLib.getLogString(logId, { result: `Successful`, length: entitysToGetAndCount[1].length }));
                },
                (error) => {
                    let errorMessage = `Error: ${error.message}`;
                    GetQueryRouteByAssetController.logger.error(CommonLib.getLogString(logId, { error: errorMessage }));
                    res.status(500);
                    res.json({ message: errorMessage });
                });
    }
}

/***/
export interface IPaginationParam extends Query {
    paginationParam: string;
}


/***/
interface Param extends ParamsDictionary {
    dt_start: string;
    dt_end: string;
}
