/***/
export class NotFound {
    /***/
    constructor(public message: string) {
    }
}
