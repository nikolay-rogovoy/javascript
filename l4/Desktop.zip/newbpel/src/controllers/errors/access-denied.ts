/***/
export class AccessDenied {
    constructor(public message: string) {
    }
}
