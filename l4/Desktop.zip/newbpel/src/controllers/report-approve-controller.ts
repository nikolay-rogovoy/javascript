import { Request, Response, Query, ParamsDictionary } from 'express-serve-static-core';
import { Auth } from '../auth';
import { CommonLib } from '../common-lib';
import { getLogger } from '../libs/logger';
import { BaseAuthController } from './base-auth-controller';
import { fromPromise } from 'rxjs/observable/fromPromise';
import { switchMap, map, mergeMap, reduce } from 'rxjs/operators';
import { _throw } from 'rxjs/observable/throw';
import { of } from 'rxjs/observable/of';
import { MetadataTable } from '../model/metadata';
import { Observable, Observer } from 'rxjs';
import { SetWoStatusController } from './set-wo-status-controller';
import { from } from 'rxjs/observable/from';
import { forkJoin } from 'rxjs/observable/forkJoin';
const pdf = require('pdf-creator-node');
const fs = require('fs');

/***/
export class ReportApproveController extends BaseAuthController {

    /***/
    static logger = getLogger(module);

    /***/
    auth = new Auth();

    /***/
    constructor() {
        super();
    }

    /***/
    async handler(req: Request<Param, any, ReqBody, IPaginationParam>, res: Response) {
        const logId = this.getLogId();
        ReportApproveController.logger.debug(CommonLib.getLogString(logId, `handleRoutes post report_approve`));

        let dt = req.body.dt;
        let fileName = 'approve.pdf';
        let queryOrderNum = `select '2022-' || replace(TO_CHAR(TO_NUMBER(replace(max(wdj10.attribute10),'2022-',''))+1,'000'),' ','') as "order_num" from wip_discrete_jobs wdj10 where wdj10.organization_id = 83`;

        CommonLib.select(queryOrderNum)
        .pipe(
            switchMap((data: {order_num: string}[]) => {
                let orderNum = data[0].order_num;
                return of(req.body.positions.filter(x => x.work_order_status_pending.indexOf('Approve') !== -1 || x.work_order_status_pending.indexOf('Printed') !== -1))
                .pipe(
                    switchMap((positions) => {
                        return from(positions)
                        .pipe(
                            mergeMap((position) => {
                                let query2 = `
                                update wip_discrete_jobs
                                set attribute10='${orderNum}'
                                where wip_entity_id = ${position.wip_entity_id}
                                and organization_id = 83`;
                                return forkJoin([
                                    SetWoStatusController.setStatus(position.wip_entity_id, 'printed', this.authorizationResult.user.user_name),
                                    CommonLib.execute(query2)
                                ]);
                            }),
                            reduce((acc, val) => {
                                acc.push(val);
                                return acc;
                            }, []),
                            switchMap(() => {
                                // Read HTML Template
                                return Observable.create((observer: Observer<string>) => {
                                    fs.readFile('reports/approve.html', 'utf8', (error, reportHTML) => {
                                        if(error) {
                                            observer.error(error);
                                        } else {
                                            observer.next(reportHTML);
                                            observer.complete();
                                        }
                                    });
                                });

                            }),
                            switchMap((reportHTML: string) => {
                                var options = {
                                    format: "A4",
                                    orientation: "portrait",
                                    border: "10mm",
                                    header: {
                                        height: "0mm",
                                        contents: ''
                                    },
                                    footer: {
                                        height: "10mm",
                                        contents: {
                                            default: '<span style="color: gray;">{{page}}</span>/<span>{{pages}}</span>', // fallback value
                                        }
                                    }
                                };
                                
                                var document = {
                                    html: reportHTML,
                                    data: {
                                        orders: positions,
                                        head: req.body.head.map(x => {
                                            return { ...x, orderNum };
                                        }),
                                    },
                                    path: `./${fileName}`,
                                    type: '',
                                };
                                return fromPromise(pdf.create(document, options));
                            }),
                            switchMap(() => {
                                return Observable.create((observer: Observer<string>) => {
                                    fs.readFile(`./${fileName}`, (error, reportPDF) => {
                                        if(error) {
                                            observer.error(error);
                                        } else {
                                            observer.next(reportPDF.toString('base64'));
                                            observer.complete();
                                        }
                                    });
                                });
                            })
                        );
                    }),
                )
            })
        ).subscribe(
                (reportPDF) => {
                    res.json({
                        message: 'Successful',
                        result: reportPDF
                    });
                    ReportApproveController.logger.debug(CommonLib.getLogString(logId, { result: `Successful` }));
                },
                (error) => {
                    let errorMessage = `Error: ${error.message}`;
                    ReportApproveController.logger.error(CommonLib.getLogString(logId, { error: errorMessage }));
                    res.status(500);
                    res.json({ message: errorMessage });
                });
    }
}

/***/
export interface IPaginationParam extends Query {
    paginationParam: string;
}


/***/
interface Param extends ParamsDictionary {
}

/***/
interface ReqBody {
    /***/
    dt: Date;
    /***/
    everythingExceptGenerators: boolean;
    /***/
    generatorsOnly: boolean;
    /***/
    positions: any[];
    /***/
    head: any[];
}