import { Request, Response, Query, ParamsDictionary } from 'express-serve-static-core';
import { Auth } from '../auth';
import { CommonLib } from '../common-lib';
import { getLogger } from '../libs/logger';
import { BaseAuthController } from './base-auth-controller';
import { switchMap, map } from 'rxjs/operators';
import { _throw } from 'rxjs/observable/throw';
import { of } from 'rxjs/observable/of';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { IRequestPaginationParam } from '../i-request-pagination-param';
import { CmmsWo } from '../model/cmms/cmms-wo';

/***/
export class GetWoByNameController extends BaseAuthController {

    /***/
    static logger = getLogger(module);

    /***/
    auth = new Auth();

    /***/
    constructor() {
        super();
    }

    /***/
    async handler(req: Request<Param, any, any, IPaginationParam>, res: Response) {
        const logId = this.getLogId();
        GetWoByNameController.logger.debug(CommonLib.getLogString(logId, `handleRoutes get wo_by_name ${req.params.wo_name}`));

        let paginationParam = req.query.paginationParam ? <IRequestPaginationParam>JSON.parse(req.query.paginationParam) : null;
        let query = `select * from table(LUKOIL_EAM_REPORTS.WO_PO_Certificate_List (to_date('01-01-2021', 'DD-MM-YYYY'),to_date('26-12-2023', 'DD-MM-YYYY'))) where "Work Order No" like '%${req.params.wo_name}%'`;
        CommonLib.select(query)
            .pipe(
                map((data: any[]) => {
                    GetWoByNameController.logger.debug(CommonLib.getLogString(logId, data));
                    return data.map(row => {
                        return {
                            work_order_no: row['Work Order No'],
                            attribute1: row['ATTRIBUTE1'],
                            work_order_type: row['WORK ORDER TYPE'],
                            attribute4: CommonLib.parseOracleDate(row['ATTRIBUTE4']),
                            asset_number: row['Asset Number'],
                            asset_description: row['Asset Description'],
                            department: row['Department'],
                            wip_accounting_class: row['WIP Accounting Class'],
                            qty: row['qty'],
                            contract_line: row['Contract Line'],
                            description: row['DESCRIPTION'],
                            activity: row['Activity'],
                            unit_rate: row['unit_rate'],
                        }
                    });
                }),
                switchMap((entities: CmmsWo[]) => {
                    return forkJoin(
                        of(entities.length),
                        of(entities));
                }),
            ).subscribe(
                (entitysToGetAndCount: [number, any[]]) => {
                    console.log("test", entitysToGetAndCount[1]);

                    res.json({
                        message: 'Successful',
                        result: {
                            data: entitysToGetAndCount[1],
                            count: entitysToGetAndCount[0],
                            limit: paginationParam ? paginationParam.limit : null,
                            offset: paginationParam ? paginationParam.offset : null
                        }
                    });
                    GetWoByNameController.logger.debug(CommonLib.getLogString(logId, { result: `Successful`, length: entitysToGetAndCount[1].length }));
                },
                (error) => {
                    let errorMessage = `Error: ${error.message}`;
                    GetWoByNameController.logger.error(CommonLib.getLogString(logId, { error: errorMessage }));
                    res.status(500);
                    res.json({ message: errorMessage });
                });
    }
}

/***/
export interface IPaginationParam extends Query {
    paginationParam: string;
}


/***/
interface Param extends ParamsDictionary {
    wo_name: string;
}
