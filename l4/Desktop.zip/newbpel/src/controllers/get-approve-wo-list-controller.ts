import { Request, Response, Query, ParamsDictionary } from 'express-serve-static-core';
import { Auth } from '../auth';
import { CommonLib } from '../common-lib';
import { getLogger } from '../libs/logger';
import { BaseAuthController } from './base-auth-controller';
import { switchMap, map } from 'rxjs/operators';
import { _throw } from 'rxjs/observable/throw';
import { of } from 'rxjs/observable/of';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { IRequestPaginationParam } from '../i-request-pagination-param';

/***/
export class GetApproveWoListController extends BaseAuthController {

    /***/
    static logger = getLogger(module);

    /***/
    auth = new Auth();

    /***/
    constructor() {
        super();
    }

    /***/
    async handler(req: Request<Param, any, any, IPaginationParam>, res: Response) {
        const logId = this.getLogId();
        GetApproveWoListController.logger.debug(CommonLib.getLogString(logId, `handleRoutes get approve_wo_list: dt = ${req.params.dt}; everythingExceptGenerators = ${req.params.everythingExceptGenerators}; generatorsOnly = ${req.params.generatorsOnly}`));

        let paginationParam = req.query.paginationParam ? <IRequestPaginationParam>JSON.parse(req.query.paginationParam) : null;

        let query = `select t.* from table(LUKOIL_EAM_REPORTS.ApproveWO('${req.params.dt}')) t`;
        GetApproveWoListController.logger.debug(CommonLib.getLogString(logId, query));
        let ac = ['ECL-PL-010', 'ECL-PL-009', 'ECL-EL-022', 'ECL-EL-023'];
        let everythingExceptGenerators = req.params.everythingExceptGenerators.toLowerCase() === 'true';
        let generatorsOnly = req.params.generatorsOnly.toLowerCase() === 'true';
        CommonLib.select(query)
            .pipe(
                map((data: any[]) => {
                    return data
                    .filter(x => (everythingExceptGenerators && ac.indexOf(x.activity) === -1)
                    || (generatorsOnly && ac.indexOf(x.activity) !== -1)
                    )
                    .map(row => {
                        return {
                            wip_entity_id: row['wip_entity_id'],
                            order_num: row['order_num'],
                            user_text: row['user_text'],
                            canceler: row['canceler'],
                            user_info: `${row['canceler'] ? row['canceler'] + ': ' : ''}${row['user_text'] ? row['user_text'] : ''}`,
                            work_order_no: row['work_order_no'],
                            work_order_status_pending: row['work_order_status_pending'],
                            work_order_type: row['work_order_type'],
                            description: row['description'],
                            completion_date: row['completion_date'],
                            scheduled_start_date: row['scheduled_start_date'],
                            scheduled_completion_date: row['scheduled_completion_date'],
                            asset_number: row['asset_number'],
                            asset_description: row['asset_description'],
                            activity: row['activity'],
                            wip_accounting_class: row['wip_accounting_class'],
                            qty: Number.parseFloat(row['qty']),
                            unit_rate: Number.parseFloat(row['unit_rate']),
                            sm: Number.parseFloat(row['qty']) * Number.parseFloat(row['unit_rate']),
                        }
                    });
                }),
                switchMap((entities: ApproveWoList[]) => {
                    return forkJoin(
                        of(entities.length),
                        of(entities));
                }),
            ).subscribe(
                (entitysToGetAndCount: [number, any[]]) => {
                    res.json({
                        message: 'Successful',
                        result: {
                            data: entitysToGetAndCount[1],
                            count: entitysToGetAndCount[0],
                            limit: paginationParam ? paginationParam.limit : null,
                            offset: paginationParam ? paginationParam.offset : null
                        }
                    });
                    GetApproveWoListController.logger.debug(CommonLib.getLogString(logId, { result: `Successful`, length: entitysToGetAndCount[1].length }));
                },
                (error) => {
                    let errorMessage = `Error: ${error.message}`;
                    GetApproveWoListController.logger.error(CommonLib.getLogString(logId, { error: errorMessage }));
                    res.status(500);
                    res.json({ message: errorMessage });
                });
    }
}

/***/
export interface IPaginationParam extends Query {
    paginationParam: string;
}


/***/
interface Param extends ParamsDictionary {
    dt: string;
    everythingExceptGenerators: string;
    generatorsOnly: string;
}

interface ApproveWoList {
    wip_entity_id: string;
    order_num: string;
    work_order_no: string;
    work_order_status_pending: string;
    work_order_type: string;
    description: string;
    completion_date: string;
    scheduled_start_date: string;
    scheduled_completion_date: string;
    asset_number: string;
    asset_description: string;
    activity: string;
    wip_accounting_class: string;
    qty: number;
    unit_rate: number;
    sm: number;
}
