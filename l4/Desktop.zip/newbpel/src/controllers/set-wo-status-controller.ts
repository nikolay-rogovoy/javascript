import { Request, Response } from 'express-serve-static-core';
import { Observable } from 'rxjs/Observable';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { from } from 'rxjs/observable/from';
import { fromPromise } from 'rxjs/observable/fromPromise';
import { getLogger } from '../libs/logger';
import { BaseAuthController } from './base-auth-controller';
import { _throw } from 'rxjs/observable/throw';
import { MetadataTable } from '../model/metadata';
import { CommonLib } from '../common-lib';
import { of } from 'rxjs/observable/of';


/***/
class NotFoundEntity {
  /***/
  constructor(public message: string) {
  }
}

/***/
export class SetWoStatusController extends BaseAuthController {

  /***/
  static logger = getLogger(module);

  /***/
  constructor() {
    super();
  }

  /***/
  async handler(req: Request, res: Response) {
    const logId = this.getLogId();
    SetWoStatusController.logger.debug(CommonLib.getLogString(logId, `handleRoutes -> post SetWoStatusController ${JSON.stringify(req.body)}`));

    SetWoStatusController.setStatus(req.body.id, req.body.status, this.authorizationResult.user.user_name)
      .subscribe(() => {
        res.json({
          message: 'Successful',
        });
        SetWoStatusController.logger.debug(CommonLib.getLogString(logId, `Change status successful`));
      },
        (error => {
          this.handleError(error, logId, req, res);
        })
      );
  }

  static setStatus(id: number, status: 'cancel' | 'release' | 'printed' | 'approved' | 'postpone', userName: string) {
    let user_defined_status_id;
    let status_type;
    let approver = null;
    let canceler = null;
    //4000	3	Luk PM Cancelled	Released
    //3	3	Released	Released
    //2000	3	Printed	Released
    //5000	3	Approved	Released
    //6 6	On Hold	On Hold
    switch (status) {
      case 'cancel':
        user_defined_status_id = '4000';
        status_type = '3';
        canceler = userName;
        break;
      case 'release':
        user_defined_status_id = '3';
        status_type = '3';
        break;
      case 'printed':
        user_defined_status_id = '2000';
        status_type = '3';
        break;
      case 'approved':
        user_defined_status_id = '5000';
        status_type = '3';
        approver = userName;
        break;
      case 'postpone':
        user_defined_status_id = '6';
        status_type = '6';
        canceler = userName;
        break;
      default:
        user_defined_status_id = '3';
        status_type = '3';
        break;
    }
    let query1 = `
    update eam_work_order_details
    set user_defined_status_id = ${user_defined_status_id}
    where wip_entity_id = ${id}
      and organization_id = 83`;
    let query2 = `
    update wip_discrete_jobs
    set status_type=${status_type} ${approver ? `, attribute12='` + approver + `'` : ''} ${canceler ? `, attribute11='` + canceler + `'` : ''}
    where wip_entity_id = ${id}
      and organization_id = 83`;
    // console.log(query1, query2);
    return forkJoin([CommonLib.execute(query1), CommonLib.execute(query2)]);
  }

  /***/
  handleError(error, logId: number, req: Request, res: Response) {
    if (error instanceof NotFoundEntity) {
      SetWoStatusController.logger.error(CommonLib.getLogString(logId, { error: error.message }));
      res.status(404);
      res.json({ message: error.message });
      SetWoStatusController.logger.error(CommonLib.getLogString(logId, { body: req.body }));
    }
    else {
      let errorMessage = `Request Execution Error: ${error.message ? error.message : error}`;
      SetWoStatusController.logger.error(CommonLib.getLogString(logId, { error: errorMessage }));
      SetWoStatusController.logger.error(CommonLib.getLogString(logId, { body: req.body }));
      res.status(500);
      res.json({ message: errorMessage });
    }
  }

}
