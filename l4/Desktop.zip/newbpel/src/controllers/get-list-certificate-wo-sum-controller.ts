import { Request, Response, Query, ParamsDictionary } from 'express-serve-static-core';
import { Auth } from '../auth';
import { CommonLib } from '../common-lib';
import { getLogger } from '../libs/logger';
import { BaseAuthController } from './base-auth-controller';
import { switchMap, map } from 'rxjs/operators';
import { _throw } from 'rxjs/observable/throw';
import { of } from 'rxjs/observable/of';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { IRequestPaginationParam } from '../i-request-pagination-param';
import { CmmsWoSum } from '../model/cmms/cmms-wo-sum';

/***/
export class GetListCertificateWoSumController extends BaseAuthController {

    /***/
    static logger = getLogger(module);

    /***/
    auth = new Auth();

    /***/
    constructor() {
        super();
    }

    /***/
    async handler(req: Request<Param, any, any, IPaginationParam>, res: Response) {
        const logId = this.getLogId();
        GetListCertificateWoSumController.logger.debug(CommonLib.getLogString(logId, `handleRoutes get list certificate sum wo ${req.params.dt_start} ${req.params.dt_end}`));

        let paginationParam = req.query.paginationParam ? <IRequestPaginationParam>JSON.parse(req.query.paginationParam) : null;

        let query = `select * from table(LUKOIL_EAM_REPORTS.WO_PO_Certificate_Sum (to_date('${req.params.dt_start}', 'DD-MM-YYYY'),to_date('${req.params.dt_end}', 'DD-MM-YYYY')))`;
        console.log(query);
        CommonLib.select(query)
            .pipe(
                map((data: any[]) => {
                    return data.map(row => {
                        return {
                            attribute1: row['ATTRIBUTE1'],
                            department: row['Department'],
                            wip_accounting_class: row['WIP Accounting Class'],
                            qty: row['qty'],
                            contract_line: row['Contract Line'],
                            cost_center_description: row['Cost Center Description'],
                            description: row['DESCRIPTION'],
                            activity: row['Activity'],
                            unit_rate: row['unit_rate'],
                        }
                    });
                }),                switchMap((entities: CmmsWoSum[]) => {
                    return forkJoin(
                        of(entities.length),
                        of(entities));
                }),
            ).subscribe(
                (entitysToGetAndCount: [number, any[]]) => {
                    res.json({
                        message: 'Successful',
                        result: {
                            data: entitysToGetAndCount[1],
                            count: entitysToGetAndCount[0],
                            limit: paginationParam ? paginationParam.limit : null,
                            offset: paginationParam ? paginationParam.offset : null
                        }
                    });
                    GetListCertificateWoSumController.logger.debug(CommonLib.getLogString(logId, { result: `Successful`, length: entitysToGetAndCount[1].length }));
                },
                (error) => {
                    let errorMessage = `Error: ${error.message}`;
                    GetListCertificateWoSumController.logger.error(CommonLib.getLogString(logId, { error: errorMessage }));
                    res.status(500);
                    res.json({ message: errorMessage });
                });
    }
}

/***/
export interface IPaginationParam extends Query {
    paginationParam: string;
}


/***/
interface Param extends ParamsDictionary {
    dt_start: string;
    dt_end: string;
}
