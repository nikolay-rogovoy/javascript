import { Request, Response } from 'express-serve-static-core';
import { getLogger } from '../libs/logger';
import { BaseAuthController } from './base-auth-controller';
import { _throw } from 'rxjs/observable/throw';
import { CommonLib } from '../common-lib';


/***/
class NotFoundEntity {
  /***/
  constructor(public message: string) {
  }
}

/***/
export class SetWoUserTextController extends BaseAuthController {

  /***/
  static logger = getLogger(module);

  /***/
  constructor() {
    super();
  }

  /***/
  async handler(req: Request, res: Response) {
    const logId = this.getLogId();
    SetWoUserTextController.logger.debug(CommonLib.getLogString(logId, `handleRoutes -> post SetWoUserTextController ${JSON.stringify(req.body)}`));

    SetWoUserTextController.setUserText(req.body.id, req.body.user_text)
      .subscribe(() => {
        res.json({
          message: 'Successful',
        });
        SetWoUserTextController.logger.debug(CommonLib.getLogString(logId, `Successful`));
      },
        (error => {
          this.handleError(error, logId, req, res);
        })
      );
  }

  static setUserText(id: number, text: string) {
    let query = `
    update wip_discrete_jobs
    set attribute15='${text}'
    where wip_entity_id = ${id}
      and organization_id = 83`;
    return CommonLib.execute(query);
  }

  /***/
  handleError(error, logId: number, req: Request, res: Response) {
    if (error instanceof NotFoundEntity) {
      SetWoUserTextController.logger.error(CommonLib.getLogString(logId, { error: error.message }));
      res.status(404);
      res.json({ message: error.message });
      SetWoUserTextController.logger.error(CommonLib.getLogString(logId, { body: req.body }));
    }
    else {
      let errorMessage = `Request Execution Error: ${error.message ? error.message : error}`;
      SetWoUserTextController.logger.error(CommonLib.getLogString(logId, { error: errorMessage }));
      SetWoUserTextController.logger.error(CommonLib.getLogString(logId, { body: req.body }));
      res.status(500);
      res.json({ message: errorMessage });
    }
  }

}
