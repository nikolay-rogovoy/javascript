import { Request, Response } from 'express-serve-static-core';
import { getLogger } from '../libs/logger';
import { BaseAuthController } from './base-auth-controller';
import { _throw } from 'rxjs/observable/throw';
import { CommonLib } from '../common-lib';
import { of } from 'rxjs/observable/of';


/***/
class NotFoundEntity {
  /***/
  constructor(public message: string) {
  }
}

/***/
export class SetWoStartDateController extends BaseAuthController {

  /***/
  static logger = getLogger(module);

  /***/
  constructor() {
    super();
  }

  /***/
  async handler(req: Request, res: Response) {
    const logId = this.getLogId();
    SetWoStartDateController.logger.debug(CommonLib.getLogString(logId, `handleRoutes -> post SetWoStartDateController ${JSON.stringify(req.body)}`));

    SetWoStartDateController.setStartDate(req.body.id, new Date(Date.parse(req.body.dt)))
      .subscribe(() => {
        res.json({
          message: 'Successful',
        });
        SetWoStartDateController.logger.debug(CommonLib.getLogString(logId, `Successful`));
      },
        (error => {
          this.handleError(error, logId, req, res);
        })
      );
  }

  static setStartDate(id: number, dt: Date) {
    let query = `
    update wip_discrete_jobs
    set scheduled_start_date='${CommonLib.getOracleData(dt)}', scheduled_completion_date='${CommonLib.getOracleData(dt)}'
    where wip_entity_id = ${id}
      and organization_id = 83`;
    return CommonLib.execute(query);
    // console.log(query);
    // return of({});
  }

  /***/
  handleError(error, logId: number, req: Request, res: Response) {
    if (error instanceof NotFoundEntity) {
      SetWoStartDateController.logger.error(CommonLib.getLogString(logId, { error: error.message }));
      res.status(404);
      res.json({ message: error.message });
      SetWoStartDateController.logger.error(CommonLib.getLogString(logId, { body: req.body }));
    }
    else {
      let errorMessage = `Request Execution Error: ${error.message ? error.message : error}`;
      SetWoStartDateController.logger.error(CommonLib.getLogString(logId, { error: errorMessage }));
      SetWoStartDateController.logger.error(CommonLib.getLogString(logId, { body: req.body }));
      res.status(500);
      res.json({ message: errorMessage });
    }
  }

}
