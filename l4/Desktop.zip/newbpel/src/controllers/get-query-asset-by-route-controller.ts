import { Request, Response, Query, ParamsDictionary } from 'express-serve-static-core';
import { Auth } from '../auth';
import { CommonLib } from '../common-lib';
import { getLogger } from '../libs/logger';
import { BaseAuthController } from './base-auth-controller';
import { switchMap, map } from 'rxjs/operators';
import { _throw } from 'rxjs/observable/throw';
import { of } from 'rxjs/observable/of';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { IRequestPaginationParam } from '../i-request-pagination-param';

/***/
export class GetQueryAssetByRouteController extends BaseAuthController {

    /***/
    static logger = getLogger(module);

    /***/
    auth = new Auth();

    /***/
    constructor() {
        super();
    }

    /***/
    async handler(req: Request<Param, any, any, IPaginationParam>, res: Response) {
        const logId = this.getLogId();
        GetQueryAssetByRouteController.logger.debug(CommonLib.getLogString(logId, `handleRoutes get asset by route ${req.params.name}`));

        let paginationParam = req.query.paginationParam ? <IRequestPaginationParam>JSON.parse(req.query.paginationParam) : null;
        let query = `select t.* from table(LUKOIL_EAM_REPORTS.GetRouteAssetDetails('${req.params.name}')) t`;
        /*
        Route_ID,
        Route_Number,
        Start_Date,
        End_Date,
        Asset_ID,
        Asset_Number,
        Asset_Group
        */
        GetQueryAssetByRouteController.logger.debug(query);
        CommonLib.select(query)
            .pipe(
                map((data: any[]) => {
                    GetQueryAssetByRouteController.logger.debug(`data.length = ${data.length}`);
                    return data.map(row => {
                        // GetQueryAssetByRouteController.logger.debug(`${row['Start_Date']}; ${row['End_Date']}; row = ${row}`);
                        return {
                            Route_ID: row['Route_ID'],
                            Route_Number: row['Route_Number'],
                            Start_Date: row['Start_Date'],
                            End_Date: row['End_Date'],
                            Asset_ID: row['Asset_ID'],
                            Asset_Number: row['Asset_Number'],
                            Asset_Group: row['Asset_Group'],
                        }
                    });
                }),
                switchMap((entities: any[]) => {
                    return forkJoin(
                        of(entities.length),
                        of(entities));
                }),
            ).subscribe(
                (entitysToGetAndCount: [number, any[]]) => {
                    res.json({
                        message: 'Successful',
                        result: {
                            data: entitysToGetAndCount[1],
                            count: entitysToGetAndCount[0],
                            limit: paginationParam ? paginationParam.limit : null,
                            offset: paginationParam ? paginationParam.offset : null
                        }
                    });
                    GetQueryAssetByRouteController.logger.debug(CommonLib.getLogString(logId, { result: `Successful`, length: entitysToGetAndCount[1].length }));
                },
                (error) => {
                    let errorMessage = `Error: ${error.message}`;
                    GetQueryAssetByRouteController.logger.error(CommonLib.getLogString(logId, { error: errorMessage }));
                    res.status(500);
                    res.json({ message: errorMessage });
                });
    }

    // static parseOracleDate(source: string): Date {
    //     GetQueryAssetByRouteController.logger.debug(`parseOracleDate 1 ${source}`);
    //     if(source == null) {
    //         return null;
    //     }
    //     GetQueryAssetByRouteController.logger.debug(`parseOracleDate 2 ${source}`);

    //     let parts = source.split('-');
    //     if(parts.length === 3){
    //         return new Date(Date.parse(`20${parts[2]}-${CommonLib.getJSMonthFromOracleMonth(parts[1])}-${CommonLib.padStart(parts[0], 2, '0')} 12:00:00`));
    //     } else {
    //         return null;
    //     }
    // }

}

/***/
export interface IPaginationParam extends Query {
    paginationParam: string;
}


/***/
interface Param extends ParamsDictionary {
    dt_start: string;
    dt_end: string;
}
