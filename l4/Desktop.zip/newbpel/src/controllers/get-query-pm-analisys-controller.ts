import { Request, Response, Query, ParamsDictionary } from 'express-serve-static-core';
import { Auth } from '../auth';
import { CommonLib } from '../common-lib';
import { getLogger } from '../libs/logger';
import { BaseAuthController } from './base-auth-controller';
import { switchMap, map } from 'rxjs/operators';
import { _throw } from 'rxjs/observable/throw';
import { of } from 'rxjs/observable/of';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { IRequestPaginationParam } from '../i-request-pagination-param';
import { CmmsWo } from '../model/cmms/cmms-wo';

/***/
export class GetQueryPmAnalisysController extends BaseAuthController {

    /***/
    static logger = getLogger(module);

    /***/
    auth = new Auth();

    /***/
    constructor() {
        super();
    }

    /***/
    async handler(req: Request<Param, any, any, IPaginationParam>, res: Response) {
        const logId = this.getLogId();
        GetQueryPmAnalisysController.logger.debug(CommonLib.getLogString(logId, `handleRoutes get query pm analisys`));

        let paginationParam = req.query.paginationParam ? <IRequestPaginationParam>JSON.parse(req.query.paginationParam) : null;
        let query = `select * from (select SERIAL_NUMBER, DESCRIPTIVE_TEXT, AREA from mtl_eam_asset_numbers_all_v where CONCATENATED_SEGMENTS like 'HAVE' and CURRENT_ORGANIZATION_ID = 83) eq , 
        (select pms.serial_number as SERIAL_NUMBER_1, pms.NAME as PM_NUM, pmr.DAY_INTERVAL from eam_pm_schedulings_v pms , EAM.EAM_PM_SCHEDULING_RULES pmr where pmr.pm_schedule_id = pms.pm_schedule_id and TO_EFFECTIVE_DATE is null and ORGANIZATION_ID = 83) pm, 
        (select SCHEDULED_START_DATE, DESCRIPTION,  PM_NAME  from EAM_OUTSTANDING_WORK_ORDERS_V)owo
        where eq.serial_number = pm.serial_number_1(+) and pm.pm_num = owo.pm_name(+)`;
        GetQueryPmAnalisysController.logger.debug(query);
        CommonLib.select(query)
            .pipe(
                map((data: any[]) => {
                    GetQueryPmAnalisysController.logger.debug(`data.length = ${data.length}`);
                    return data.map(row => {
                        return {
                            ... row,
                        }
                    });
                }),
                switchMap((entities: CmmsWo[]) => {
                    return forkJoin(
                        of(entities.length),
                        of(entities));
                }),
            ).subscribe(
                (entitysToGetAndCount: [number, any[]]) => {
                    res.json({
                        message: 'Successful',
                        result: {
                            data: entitysToGetAndCount[1],
                            count: entitysToGetAndCount[0],
                            limit: paginationParam ? paginationParam.limit : null,
                            offset: paginationParam ? paginationParam.offset : null
                        }
                    });
                    GetQueryPmAnalisysController.logger.debug(CommonLib.getLogString(logId, { result: `Successful`, length: entitysToGetAndCount[1].length }));
                },
                (error) => {
                    let errorMessage = `Error: ${error.message}`;
                    GetQueryPmAnalisysController.logger.error(CommonLib.getLogString(logId, { error: errorMessage }));
                    res.status(500);
                    res.json({ message: errorMessage });
                });
    }
}

/***/
export interface IPaginationParam extends Query {
    paginationParam: string;
}


/***/
interface Param extends ParamsDictionary {
    dt_start: string;
    dt_end: string;
}
