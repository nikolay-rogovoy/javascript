import { Request, Response, Query, ParamsDictionary } from 'express-serve-static-core';
import { Auth } from '../auth';
import { CommonLib } from '../common-lib';
import { getLogger } from '../libs/logger';
import { BaseAuthController } from './base-auth-controller';
import { switchMap, map } from 'rxjs/operators';
import { _throw } from 'rxjs/observable/throw';
import { of } from 'rxjs/observable/of';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { IRequestPaginationParam } from '../i-request-pagination-param';
import { CmmsWo } from '../model/cmms/cmms-wo';

/***/
export class GetQueryWoStatisticController extends BaseAuthController {

    /***/
    static logger = getLogger(module);

    /***/
    auth = new Auth();

    /***/
    constructor() {
        super();
    }

    /***/
    async handler(req: Request<Param, any, any, IPaginationParam>, res: Response) {
        const logId = this.getLogId();
        GetQueryWoStatisticController.logger.debug(CommonLib.getLogString(logId, `handleRoutes get query wo statistic ${req.params.dt_start} ${req.params.dt_end}`));

        let paginationParam = req.query.paginationParam ? <IRequestPaginationParam>JSON.parse(req.query.paginationParam) : null;
        let query = `select * from table(LUKOIL_EAM_REPORTS.WO_STATISTIC ('${req.params.dt_start}', '${req.params.dt_end}'))`;
        GetQueryWoStatisticController.logger.debug(query);
        CommonLib.select(query)
            .pipe(
                map((data: any[]) => {
                    GetQueryWoStatisticController.logger.debug(`data.length = ${data.length}`);
                    return data.map(row => {
                        return {
                            ... row,
                        }
                    });
                }),
                switchMap((entities: CmmsWo[]) => {
                    return forkJoin(
                        of(entities.length),
                        of(entities));
                }),
            ).subscribe(
                (entitysToGetAndCount: [number, any[]]) => {
                    res.json({
                        message: 'Successful',
                        result: {
                            data: entitysToGetAndCount[1],
                            count: entitysToGetAndCount[0],
                            limit: paginationParam ? paginationParam.limit : null,
                            offset: paginationParam ? paginationParam.offset : null
                        }
                    });
                    GetQueryWoStatisticController.logger.debug(CommonLib.getLogString(logId, { result: `Successful`, length: entitysToGetAndCount[1].length }));
                },
                (error) => {
                    let errorMessage = `Error: ${error.message}`;
                    GetQueryWoStatisticController.logger.error(CommonLib.getLogString(logId, { error: errorMessage }));
                    res.status(500);
                    res.json({ message: errorMessage });
                });
    }
}

/***/
export interface IPaginationParam extends Query {
    paginationParam: string;
}


/***/
interface Param extends ParamsDictionary {
    dt_start: string;
    dt_end: string;
}
