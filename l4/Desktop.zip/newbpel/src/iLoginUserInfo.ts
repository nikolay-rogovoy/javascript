/***/
export interface ILoginUserInfo {
    /***/
    iduser: number;
    user_name: string;
}