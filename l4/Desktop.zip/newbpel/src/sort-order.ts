/***/
export enum SortOrder {
    /***/
    asc = 1,
    /***/
    desc = 0
}
