import { CmmsWo } from '../model/cmms/cmms-wo';
import { Table } from './table';

export class CmmsWoTable extends Table<CmmsWo> {
}
