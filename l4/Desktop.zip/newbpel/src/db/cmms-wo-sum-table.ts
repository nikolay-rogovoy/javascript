import { CmmsWoSum } from '../model/cmms/cmms-wo-sum';
import { Table } from './table';

export class CmmsWoSumTable extends Table<CmmsWoSum> {
}
