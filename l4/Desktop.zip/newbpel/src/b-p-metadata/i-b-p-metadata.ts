/***/
export interface IBPMetadata {
}
