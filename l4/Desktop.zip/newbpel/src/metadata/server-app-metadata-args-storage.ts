import { ISaveDataStrategyStorageItem } from '../interfaces/i-save-data-strategy-storage-item';

/***/
export class ServerAppMetadataArgsStorage {
    /***/
    saveDataStrategyStorageItem: ISaveDataStrategyStorageItem[] = [];
}
