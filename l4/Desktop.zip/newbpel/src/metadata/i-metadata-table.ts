export interface IMetadataTable {
    [index: string]: number;
}
