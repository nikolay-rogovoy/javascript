declare type TypeEditor = 'date' | 'datetime' | 'currency' | 'real' | 'integer' | 'string' | 'dictionary' | 'template' | 'textarea' | 'phone' | 'picture' | 'address' | 'double precision';
