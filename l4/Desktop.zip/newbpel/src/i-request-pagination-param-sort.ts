import { SortOrder } from './sort-order';

/***/
export interface IRequestPaginationParamSort {
    /***/
    fieldName: string;
    /***/
    order: SortOrder;
}
