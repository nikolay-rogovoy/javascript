/***/
export interface IDependency {
  key: number;
  entity_name: string;
  entity_comment: string;
  name_entity: string;
}
