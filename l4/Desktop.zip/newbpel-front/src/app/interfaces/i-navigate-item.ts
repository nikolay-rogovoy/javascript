/**Позиция навигации */
export interface INavigateItem {
    /**Роут */
    url: string;

    /**Заголовок формы */
    caption : string;
}