// import { IUserDepRoleOper } from './i-user-dep-role-oper';

/***/
export interface IUserDepPost {
    /***/
    idpost: number;
    /***/
    name: string;
}
