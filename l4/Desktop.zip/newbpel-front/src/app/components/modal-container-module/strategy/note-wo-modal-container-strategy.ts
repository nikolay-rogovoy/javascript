import { NoteWoComponent } from '../../../views/cmms/note-wo/note-wo.component';
import { IModalContainerStrategy } from '../i-modal-container-strategy';
import { ModalContainerComponent } from '../modal-container-component/modal-container-component';

/***/
export class NoteWoModalContainerStrategy implements IModalContainerStrategy<NoteWoComponent> {

  /***/
  constructor(private text: string) {
  }

  /***/
  prepare(component: NoteWoComponent, modalContainerComponent: ModalContainerComponent) {
    component.text = this.text;
    component.submit.subscribe((text: string) => {
      modalContainerComponent.ok(text);
    });
  }
}
