export class FilterInfo {
    constructor(public value: string) {
    }
}
