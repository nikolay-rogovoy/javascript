/***/
import { ColumnInfo } from './column-info';

export interface ChangedCellArgs {
    /***/
    value: any;
    /***/
    columnInfo: ColumnInfo
    /***/
    id: string;
}
