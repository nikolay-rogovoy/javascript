/***/
export interface IAtGridNgStyle {
    /***/
    [key: string]: string;
}
