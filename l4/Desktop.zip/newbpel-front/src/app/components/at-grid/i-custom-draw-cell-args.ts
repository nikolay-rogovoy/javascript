import { IAtGridNgStyle } from './i-atgrid-ng-style';

/***/
export interface ICustomDrawCellArgs {
    /***/
    ngStyle: IAtGridNgStyle;
}
