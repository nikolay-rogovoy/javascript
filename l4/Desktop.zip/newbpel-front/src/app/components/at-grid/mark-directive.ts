import { Directive } from '@angular/core';

@Directive({ selector: 'mark-directive' })
export class MarkDirective {
}
