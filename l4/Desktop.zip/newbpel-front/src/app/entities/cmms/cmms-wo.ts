export interface CmmsWo {
  work_order_no: string;
  attribute1: string;
  work_order_type: string;
  attribute4: Date;
  asset_number: string;
  asset_description: string;
  department: string;
  wip_accounting_class: string;
  qty: string;
  contract_line: string;
  description: string;
  activity: string;
  unit_rate: string;
}
