/**Сущность*/
export interface IEntity {
  [key: string]: any;
}
