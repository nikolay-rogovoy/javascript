export interface Message {
  idmessage: number;
  code: string;
  metadatacode: string;
  name: string;
  comment: string;
  active: boolean;
  dtcre: Date;
}