export interface Dep {
  iddep: number;
  idorg: number,
  name: string;
  comment: string;
  active: boolean;
  dtcre: Date;
}