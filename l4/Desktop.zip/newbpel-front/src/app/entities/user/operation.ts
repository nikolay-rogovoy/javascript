export interface Operation {
  idoperation: number;
  idorg: number,
  name: string;
  comment: string;
  dtcre: Date;
}
