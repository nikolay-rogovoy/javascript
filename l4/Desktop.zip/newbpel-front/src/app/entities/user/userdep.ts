export interface Userdep {
  iduserdep: number;
  iduser: number;
  iddep: number;
  idpost: number;
  name: string;
  comment: string;
  role_name: string;
  dep_name: string;
  user_name: string;
  dtcre: Date;
}