export interface Resource {
  idresource: number;
  name: string;
  comment: string;
  active: boolean;
  dtcre: Date;
}
