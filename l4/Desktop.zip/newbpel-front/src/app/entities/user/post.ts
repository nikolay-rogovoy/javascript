export interface Post {
  idpost: number;
  name: string;
  comment: string;
  active: boolean;
  dtcre: Date;
}