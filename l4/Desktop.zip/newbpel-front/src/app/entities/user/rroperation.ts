export interface Rroperation {
  idrroperation: number,
  idoperation: number;
  idroleresource: number;
  operation_name: string;
  roleresource_name: string;
  idorg: number;
  name: string;
  comment: string;
  dtcre: Date;
}
