export interface Operationresource {
  idoperationresource: number,
  idoperation: number;
  idresource: number;
  operation_name: string;
  resource_name: string;
  idorg: number;
  name: string;
  comment: string;
  dtcre: Date;
}
