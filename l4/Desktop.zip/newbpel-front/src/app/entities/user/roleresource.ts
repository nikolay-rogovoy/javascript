export interface Roleresource {
  idroleresource: number,
  idresource: number;
  idrole: number;
  resource_name: string;
  role_name: string;
  idorg: number;
  name: string;
  comment: string;
  dtcre: Date;
}
