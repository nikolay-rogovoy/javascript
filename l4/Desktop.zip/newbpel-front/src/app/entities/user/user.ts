export interface User {
  iduser: number;
  idorg: number;
  name: string;
  comment: string;
  pass: string;
  login: string;
  active: boolean;
  dtcre: Date;
}