export interface QueryAssetByRoute {
  Route_ID: number,
  Route_Number: string,
  Start_Date: Date,
  End_Date: Date,
  Asset_ID: number,
  Asset_Number: string,
  Asset_Group: string;
}
