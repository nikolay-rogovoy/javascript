export interface QueryWoStatistic {
}
