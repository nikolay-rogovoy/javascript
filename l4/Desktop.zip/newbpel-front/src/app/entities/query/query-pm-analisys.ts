export interface QueryPmAnalisys {
  SERIAL_NUMBER: string;
  DESCRIPTIVE_TEXT: string;
  AREA: string;
  SERIAL_NUMBER_1: string;
  PM_NUM: string;
  DAY_INTERVAL: number;
  SCHEDULED_START_DATE: Date;
  DESCRIPTION: string;
  PM_NAME: string;
}
