export interface QueryPmNew {
  AREA: string;
  SERIAL_NUMBER: string;
  DESCRIPTIVE_TEXT: string;
  ACCOUNTING_CLASS_CODE: string;
  OWNING_DEPARTMENT: string;
  NETWORK_SERIAL_NUMBER: string;
  NAME: string;
  INTERVAL_DAY: number;
  PLAN_NUM: string;
  ACTIVITY_DESCRIPTION: string;
  LAST_SERVICE_START_DATE: Date;
  ESTIM_NEXT_DATE: Date;
  NEXT_DATE: Date;
}
