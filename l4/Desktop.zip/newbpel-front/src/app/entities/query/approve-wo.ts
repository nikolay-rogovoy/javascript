export interface ApproveWo {
  wip_entity_id: string;
  order_num: string;
  work_order_no: string;
  work_order_status_pending: string;
  work_order_type: string;
  description: string;
  completion_date: Date;
  scheduled_start_date: Date;
  scheduled_completion_date: Date;
  asset_number: string;
  asset_description: string;
  activity: string;
  wip_accounting_class: string;
  qty: number;
  unit_rate: number;
  sm: number;
  user_text: string;
  canceler: string;
  user_info: string;
}
