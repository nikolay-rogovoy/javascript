/**Ошибка валидации, генерируется в декораторе*/
export class NotImplemented {
  /***/
  constructor(public message?: string) {
  }
}
