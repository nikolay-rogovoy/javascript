/**Ошибка валидации, генерируется в декораторе*/
export class NotFound {
  /***/
  constructor(public message: string) {
  }
}
