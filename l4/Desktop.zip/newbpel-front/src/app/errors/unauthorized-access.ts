/**Ошибка валидации, генерируется в декораторе*/
export class UnauthorizedAccess {
  /***/
  constructor(public message: string) {
  }
}
