/**Ошибка валидации, генерируется в декораторе*/
export class AccessDenied {
  /***/
  constructor(public message: string) {
  }
}
