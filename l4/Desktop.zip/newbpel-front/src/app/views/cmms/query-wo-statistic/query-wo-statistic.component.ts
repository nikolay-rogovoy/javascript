import { Component, Injector, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { map, switchMap } from 'rxjs/operators';
import { ColumnFormat, ColumnInfo } from '../../../components/at-grid/column-info';
import { FilterInfo } from '../../../components/at-grid/filter-info';
import { CmmsWo } from '../../../entities/cmms/cmms-wo';
import { EntityName } from '../../../entities/entity-name';
import { CancelFormDecorator } from '../../../lib/cancel-form-decorator';
import { IListComponent } from '../../../lib/i-list-component';
import { IReactiveForm } from '../../../lib/i-reactive-form';
import { InvalidControlFormDecorator } from '../../../lib/invalid-control-form-decorator';
import { LifecycleComponent } from '../../../lib/lifecycle-component';
import { ReactiveFormDecorator } from '../../../lib/reactive-form-decorator';
import { ServiceProvider } from '../../../services/service-provider';
import { CommonLib } from '../../../lib/common-lib';
import { QueryWoStatistic } from '../../../entities/query/query-wo-statistic';
@Component({
  templateUrl: 'query-wo-statistic.component.html'
})
@ReactiveFormDecorator()
@CancelFormDecorator()
@InvalidControlFormDecorator()
export class QueryWoStatisticComponent extends LifecycleComponent implements IListComponent<CmmsWo>, OnInit, IReactiveForm {

  formGroup = new FormGroup({
    dt_start: new FormControl(CommonLib.formatDate(new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDay())), Validators.required),
    dt_end: new FormControl(CommonLib.formatDate(new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDay())), Validators.required),
  });

  changed = false;

  constructor(public injector: Injector) {
    super();
  }

  positions: any[] = [];

  gridMetaData: ColumnInfo[] = [
    new ColumnInfo('WO Category', 'WO Category', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('Released', 'Released', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('Printed', 'Printed', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('Complete by Contractor', 'Complete by Contractor', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('Complete by Supervisor', 'Complete by Supervisor', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('Complete', 'Complete', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('Cancelled', 'Cancelled', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('Cancelled By PM', 'Cancelled By PM', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('Luk PM Cancelled', 'Luk PM Cancelled', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('PM Cancelled', 'PM Cancelled', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('On Hold', 'On Hold', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('Draft', 'Draft', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('Unreleased', 'Unreleased', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('Closed', 'Closed', true, new FilterInfo(''), ColumnFormat.Number, false),
  ];

  newItem() {
    throw new Error('Not implemented');
  }
  selectRow(entity) {
  }
  onInit(): void {
    this.positions = [];
  }

  runQuery(period: {dt_start: Date, dt_end: Date}) {
    let serviceProvider = this.injector.get(ServiceProvider);
    if(period.dt_end && period.dt_start){
      serviceProvider.getEntityListUrl<QueryWoStatistic>(`query_wo_statistic/${CommonLib.formatDate(period.dt_start)}/${CommonLib.formatDate(period.dt_end)}`)
        .pipe(
          map((entities: QueryWoStatistic[]) => {
            return entities;
            //return entities.map(x => serviceProvider.loadRawData(x, EntityName.cmms_wo));;
          })
        )
        .subscribe(
          (positions) => {
            this.positions = positions;
            this.acceptChanges();
          }
        );
    }
  }

  acceptChanges(): void {
    throw new Error('Not implemented');
  }
  goBack(): void {
    throw new Error('Not implemented');
  }
  getChanged(): boolean {
    throw new Error('Not implemented');
  }

  cancel() {
    throw new Error(`Not implemented`);
  }
  onSubmit() {
  }
  invalidControlClass(controlName: string) {
    throw new Error('Not implemented');
  }

  createCsv() {
    
    let csvContent = 'WO Category,Released,Printed,Complete by Contractor,Complete by Supervisor,Complete,Cancelled,Cancelled By PM,Luk PM Cancelled,PM Cancelled,On Hold,Draft,Unreleased,Closed\r\n';
    csvContent += this.positions.map(e => {
      return `${e['WO Category'] ? e['WO Category'] : ''},`+
      `${e['Released'] ? e['Released'] : '0'},`+
      `${e['Printed'] ? e['Printed'] : '0'},`+
      `${e['Complete by Contractor'] ? e['Complete by Contractor'] : '0'},`+
      `${e['Complete by Supervisor'] ? e['Complete by Supervisor'] : '0'},`+
      `${e['Complete'] ? e['Complete'] : '0'},`+
      `${e['Cancelled'] ? e['Cancelled'] : '0'},`+
      `${e['Cancelled By PM'] ? e['Cancelled By PM'] : '0'},`+
      `${e['Luk PM Cancelled'] ? e['Luk PM Cancelled'] : '0'},`+
      `${e['PM Cancelled'] ? e['PM Cancelled'] : '0'},`+
      `${e['On Hold'] ? e['On Hold'] : '0'},`+
      `${e['Draft'] ? e['Draft'] : '0'},`+
      `${e['Unreleased'] ? e['Unreleased'] : '0'},`+
      `${e['Closed'] ? e['Closed'] : '0'}`+
      ``;
      // return `${e.activity ? e.activity : ''},${e.attribute1 ? e.attribute1 : ''},${e.contract_line ? e.contract_line : ''},${e.department ? e.department : ''},${e.description ? e.description : ''},${e.qty ? e.qty : ''},${e.unit_rate ? e.unit_rate : ''},${e.wip_accounting_class ? e.wip_accounting_class : ''}`;
    }).join('\r\n');
    let blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    if ((<any>navigator).msSaveBlob) { // IE 10+
        (<any>navigator).msSaveBlob(blob, `wo_statistic_${new Date().toLocaleDateString()}.csv`);
    } else {
        let link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            let url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", `wo_statistic_${new Date().toLocaleDateString()}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }

  }

}
