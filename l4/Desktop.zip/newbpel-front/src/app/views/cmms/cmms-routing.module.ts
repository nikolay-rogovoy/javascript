import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CheckSaveGuard } from '../../lib/check-save-guard';
import { ConfirmWoComponent } from './confirm-wo/confirm-wo.component';
import { ApproveWoComponent } from './approve-wo/approve-wo.component';
import { CertificateComponent } from './certificate/certificate.component';
import { QueryAssetByRouteComponent } from './query-asset-by-route/query-asset-by-route.component';
import { QueryPmAnalisysComponent } from './query-pm-analisys/query-pm-analisys.component';
import { QueryPmNewComponent } from './query-pm-new/query-pm-new.component';
import { QueryRouteByAssetComponent } from './query-route-by-asset/query-route-by-asset.component';
import { QueryWoStatisticComponent } from './query-wo-statistic/query-wo-statistic.component';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Oracle EAM'
    },
    children: [
      {
        path: 'certificate',
        component: CertificateComponent,
        data: {
          title: 'Certificate WO'
        }
      },
      {
        path: 'wo_statistic',
        component: QueryWoStatisticComponent,
        data: {
          title: 'WO Statistic'
        }
      },
      {
        path: 'pm_analisys',
        component: QueryPmAnalisysComponent,
        data: {
          title: 'PM Analisys'
        }
      },
      {
        path: 'pm_new',
        component: QueryPmNewComponent,
        data: {
          title: 'PM New'
        }
      },
      {
        path: 'asset_by_route',
        component: QueryAssetByRouteComponent,
        data: {
          title: 'Asset by route'
        }
      },
      {
        path: 'route_by_asset',
        component: QueryRouteByAssetComponent,
        data: {
          title: 'Route by asset'
        }
      },
      {
        path: 'approve_wo',
        component: ApproveWoComponent,
        data: {
          title: 'Approve WO'
        }
      },
      {
        path: 'confirm_wo',
        component: ConfirmWoComponent,
        data: {
          title: 'Confirm WO'
        }
      },

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CmmsRoutingModule { }
