import { Component, EventEmitter, Injector, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormDecorator } from '../../../lib/reactive-form-decorator';
import { IReactiveForm } from '../../../lib/i-reactive-form';
import { InvalidControlFormDecorator } from '../../../lib/invalid-control-form-decorator';
import { LifecycleComponent } from '../../../lib/lifecycle-component';
import { CommonLib } from '../../../lib/common-lib';

@Component({
  templateUrl: 'note-date-wo.component.html'
})
@ReactiveFormDecorator()
@InvalidControlFormDecorator()
export class NoteDateWoComponent extends LifecycleComponent implements IReactiveForm, OnInit {

  formGroup = new FormGroup({
    dt: new FormControl('', Validators.required),
    text: new FormControl('', Validators.required),
  });

  private _param: { text : string, dt : Date };

  @Input()
  set param(value: { text : string, dt : Date }) {
    this._param = value;
    let patchValue = <any>{ text: this._param.text, dt: CommonLib.formatDate(this._param.dt) };

    this.formGroup.patchValue(patchValue);
  };

  @Output()
  submit = new EventEmitter<{ text : string, dt : Date }>();

  changed = false;

  constructor(public injector: Injector) {
    super();
  }

  acceptChanges(): void {
    throw new Error('Not implemented');
  }
  goBack(): void {
    throw new Error('Not implemented');
  }
  getChanged(): boolean {
    throw new Error('Not implemented');
  }

  cancel() {
    this.submit.next(null);
  }
  onSubmit() {
    this._param.text = this.formGroup.getRawValue().text;
    this._param.dt = new Date(Date.parse(this.formGroup.getRawValue().dt));
    this.submit.next(this._param);
  }
  invalidControlClass(controlName: string) {
    throw new Error('Not implemented');
  }
  isExistsEntity() {
    throw new Error('Not implemented');
  }
}
