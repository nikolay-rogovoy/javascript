import { Component, Injector, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { concatMap, map, reduce, switchMap } from 'rxjs/operators';
import { ColumnFormat, ColumnInfo } from '../../../components/at-grid/column-info';
import { FilterInfo } from '../../../components/at-grid/filter-info';
import { EntityName } from '../../../entities/entity-name';
import { CancelFormDecorator } from '../../../lib/cancel-form-decorator';
import { IListComponent } from '../../../lib/i-list-component';
import { IReactiveForm } from '../../../lib/i-reactive-form';
import { InvalidControlFormDecorator } from '../../../lib/invalid-control-form-decorator';
import { LifecycleComponent } from '../../../lib/lifecycle-component';
import { ReactiveFormDecorator } from '../../../lib/reactive-form-decorator';
import { ServiceProvider } from '../../../services/service-provider';
import { CommonLib } from '../../../lib/common-lib';
import { ConfirmWo } from '../../../entities/query/confirm-wo';
import { TemplateProviderComponent } from '../../../lib/template-provider-component/template-provider-component';
import { from } from 'rxjs';
import { Action } from 'rxjs/internal/scheduler/Action';
import { AdminLib } from '../../../lib/admin-lib';
@Component({
  templateUrl: 'confirm-wo.component.html'
})
@ReactiveFormDecorator()
@CancelFormDecorator()
@InvalidControlFormDecorator()
export class ConfirmWoComponent extends LifecycleComponent implements IListComponent<ConfirmWo>, OnInit, IReactiveForm {

  formGroup = new FormGroup({
  });

  changed = false;

  constructor(public injector: Injector) {
    super();
  }

  /***/
  @ViewChild(TemplateProviderComponent, { static: true })
  templateProvider: TemplateProviderComponent;

  positions: any[] = [];

  total_sm = 0;
  total_count = 0;

  param: {dt: Date, everythingExceptGenerators: boolean, generatorsOnly: boolean};
  /**
  wip_entity_id
  order_num
  work_order_no
  work_order_status_pending
  work_order_type
  description
  completion_date
  scheduled_start_date
  scheduled_completion_date
  asset_number
  asset_description
  activity
  wip_accounting_class
  qty
  unit_rate
  sm
  */
  gridMetaData: ColumnInfo[] = [
    new ColumnInfo('order_num', 'Order', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('work_order_no', 'WO number', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('work_order_status_pending', 'WO status', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('description', 'Description', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('activity', 'Activity', true, new FilterInfo(''), ColumnFormat.Default, false),
    // new ColumnInfo('completion_date', 'Completion', true, new FilterInfo(''), ColumnFormat.Date, false),
    new ColumnInfo('scheduled_start_date', 'Scheduled Start', true, new FilterInfo(''), ColumnFormat.Date, false),
    new ColumnInfo('asset_number', 'Asset Number', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('asset_description', 'Asset Description', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('qty', 'Qty', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('unit_rate', 'Unit Rate', true, new FilterInfo(''), ColumnFormat.Currency, false),
    new ColumnInfo('sm', 'Sm', true, new FilterInfo(''), ColumnFormat.Currency, false),
    new ColumnInfo('actions', 'Actions', true, new FilterInfo(''), ColumnFormat.Template, false),
  ];

    /***/
    getAction(position: any) {
      let showCancel = position.work_order_status_pending.indexOf('Release') !== -1 || position.work_order_status_pending.indexOf('Confirm') !== -1;
      let showRelease = position.work_order_status_pending.indexOf('Cancel') !== -1 || position.work_order_status_pending.indexOf('Confirm') !== -1;
      let showConfirmd = position.work_order_status_pending.indexOf('Release') !== -1 || position.work_order_status_pending.indexOf('Printed') !== -1;
      let showPrinted = position.work_order_status_pending.indexOf('Confirm') !== -1;
      return {
          template: this.templateProvider.gridButtons,
          context: {
              data: {
                  buttons: [
                    showCancel ? {
                          click: this.cancelWO.bind(this),
                          item: { entity: position },
                          css: { 'btn-danger': true },
                          caption: 'Cancel',
                          content: 'content_copy',
                          isMaterialIcon: true,
                          disabled: false,
                      } : null,
                      showRelease ? {
                          click: this.releaseWO.bind(this),
                          item: { entity: position },
                          css: { 'btn-info': true },
                          caption: 'Release',
                          content: 'delete',
                          isMaterialIcon: true,
                          disabled: false,
                      } : null,
                      showConfirmd ? {
                        click: this.confirmdWO.bind(this),
                        item: { entity: position },
                        css: { 'btn-success': true },
                        caption: 'Confirmd',
                        content: 'delete',
                        isMaterialIcon: true,
                        disabled: false,
                      } : null,
                      showPrinted ? {
                        click: this.printedWO.bind(this),
                        item: { entity: position },
                        css: { 'btn-dark': true },
                        caption: 'Printed',
                        content: 'delete',
                        isMaterialIcon: true,
                        disabled: false,
                    } : null,
              ].filter(x => x),
                  content: ''
              }
          }
      };
  }

  cancelWO(entity) {
    this.injector.get(ServiceProvider).postRawData('set_wo_status', { status: 'cancel', id: entity.entity.wip_entity_id })
    .subscribe(() => {
      if(this.param){
        this.runQuery(this.param);
      }
    });
  }

  releaseWO(entity) {
    this.injector.get(ServiceProvider).postRawData('set_wo_status', { status: 'release', id: entity.entity.wip_entity_id })
    .subscribe(() => {
      if(this.param){
        this.runQuery(this.param);
      }
    });
  }
  
  printedWO(entity) {
    this.injector.get(ServiceProvider).postRawData('set_wo_status', { status: 'printed', id: entity.entity.wip_entity_id })
    .subscribe(() => {
      if(this.param){
        this.runQuery(this.param);
      }
    });
  }

  confirmAllReleased() {
    let releasedWO = this.positions.filter(x => x.work_order_status_pending === 'Released');
    if(releasedWO.length) {
      from(releasedWO)
      .pipe(
        concatMap((entity) => {
          return this.injector.get(ServiceProvider).postRawData('set_wo_status', { status: 'confirmd', id: entity.wip_entity_id });
        }),
        reduce((acc, val) => {
          acc.push(val);
          return acc;
        }, [])
      )
      .subscribe(() => {
        if(this.param){
          this.runQuery(this.param);
        }
      });
    }
  }

  confirmdWO(entity) {
    this.injector.get(ServiceProvider).postRawData('set_wo_status', { status: 'confirmd', id: entity.entity.wip_entity_id })
    .subscribe(() => {
      if(this.param){
        this.runQuery(this.param);
      }
    });
  }

  newItem() {
    throw new Error('Not implemented');
  }
  selectRow(entity) {
  }
  onInit(): void {
    this.positions = [];
  }
  runQuery(param: {dt: Date, everythingExceptGenerators: boolean, generatorsOnly: boolean}) {
    this.param = param;
    let serviceProvider = this.injector.get(ServiceProvider);
    serviceProvider.getEntityListUrl<ConfirmWo>(`confirm_wo_list/${CommonLib.formatDate(param.dt)}/${param.everythingExceptGenerators}/${param.generatorsOnly}`)
      .pipe(
        map((entities: ConfirmWo[]) => {
          return entities.map(x => serviceProvider.loadRawData(x, EntityName.asset_by_route));
        })
      )
      .subscribe(
        (positions) => {
          this.positions = positions.map(x => {
            return {...x, actions: this.getAction(x)};
          });
          this.total_count = positions.length;
          let total_sm = positions.reduce((acc, val)=> {
            acc += val.sm;
            return acc;
          }, 0);
          this.total_sm = Math.round(total_sm * 100) / 100;
          this.acceptChanges();
        }
      );
  }

  acceptChanges(): void {
    throw new Error('Not implemented');
  }
  goBack(): void {
    throw new Error('Not implemented');
  }
  getChanged(): boolean {
    throw new Error('Not implemented');
  }

  cancel() {
    throw new Error(`Not implemented`);
  }
  onSubmit() {
  }
  invalidControlClass(controlName: string) {
    throw new Error('Not implemented');
  }

  createCsv() {
    let csvContent = 'Route_ID,Route_Number,Start_Date,End_Date,Asset_ID,Asset_Number,Asset_Group\r\n';
    csvContent += this.positions.map(e => {
      return `${e['Route_ID'] ? e['Route_ID'] : ''},`+
      `${e['Route_Number'] ? e['Route_Number'] : ''},`+
      `${e['Start_Date'] ? CommonLib.dateToShortString(e['Start_Date']) : ''},`+
      `${e['End_Date'] ? CommonLib.dateToShortString(e['End_Date']) : ''},`+
      `${e['Asset_ID'] ? e['Asset_ID'] : ''},`+
      `${e['Asset_Number'] ? e['Asset_Number'] : ''},`+
      `${e['Asset_Group'] ? e['Asset_Group'] : ''}`+
      ``;
    }).join('\r\n');
    let blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    if ((<any>navigator).msSaveBlob) { // IE 10+
        (<any>navigator).msSaveBlob(blob, `confirm_wo_${new Date().toLocaleDateString()}.csv`);
    } else {
        let link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            let url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", `confirm_wo_${new Date().toLocaleDateString()}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }

  }

}
