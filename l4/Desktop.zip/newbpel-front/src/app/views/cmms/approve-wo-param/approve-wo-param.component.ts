import { Component, EventEmitter, Injector, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CancelFormDecorator } from '../../../lib/cancel-form-decorator';
import { IReactiveForm } from '../../../lib/i-reactive-form';
import { InvalidControlFormDecorator } from '../../../lib/invalid-control-form-decorator';
import { LifecycleComponent } from '../../../lib/lifecycle-component';
import { ReactiveFormDecorator } from '../../../lib/reactive-form-decorator';
import { CommonLib } from '../../../lib/common-lib';
import { filter, switchMap } from 'rxjs/operators';
import { NotificationService } from '../../../services/notification-service';
import { IUserDep } from '../../../interfaces/i-user-dep';
import { of } from 'rxjs';

@Component({
  templateUrl: 'approve-wo-param.component.html',
  selector: 'approve-wo-param'
})
@ReactiveFormDecorator()
@CancelFormDecorator()
@InvalidControlFormDecorator()
export class ApproveWoParamComponent extends LifecycleComponent implements OnInit, IReactiveForm {

  @Output()
  runQuery = new EventEmitter<{ dt: Date, everythingExceptGenerators: boolean, generatorsOnly: boolean }>();

  @Output()
  printApproved = new EventEmitter<{ dt: Date, everythingExceptGenerators: boolean, generatorsOnly: boolean }>();

  formGroup = new FormGroup({
    dt: new FormControl(CommonLib.formatDate(new Date()), Validators.required),
    everythingExceptGenerators: new FormControl(true),
    generatorsOnly: new FormControl(true),
  });

  changed = true;

  isIngPlaner = false;

  constructor(public injector: Injector) {
    super();
  }

  newItem() {
    throw new Error('Not implemented');
  }

  onInit(): void {
    this.injector.get(NotificationService).dep
      .pipe(
        filter(dep => dep != null),
        switchMap((dep: IUserDep) => {
          this.isIngPlaner = dep.posts.find(x => x.idpost === 1 || x.idpost === 3) != null;
          return of(dep);
        })
      ).subscribe();
  }


  acceptChanges(): void {
    throw new Error('Not implemented');
  }
  goBack(): void {
    throw new Error('Not implemented');
  }
  getChanged(): boolean {
    throw new Error('Not implemented');
  }

  cancel() {
    throw new Error(`Not implemented`);
  }
  onSubmit() {
    // throw new Error(`Not implemented`);
  }
  onSubmitRunQuery() {
    this.runQuery.next({
      dt: new Date(Date.parse(this.formGroup.value['dt'])),
      everythingExceptGenerators: !!this.formGroup.value['everythingExceptGenerators'],
      generatorsOnly: !!this.formGroup.value['generatorsOnly'],
    });
  }
  onPrintApproved() {
    this.printApproved.next({
      dt: new Date(Date.parse(this.formGroup.value['dt'])),
      everythingExceptGenerators: !!this.formGroup.value['everythingExceptGenerators'],
      generatorsOnly: !!this.formGroup.value['generatorsOnly'],
    });
  }
  invalidControlClass(controlName: string) {
    throw new Error('Not implemented');
  }

}
