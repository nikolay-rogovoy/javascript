import { Component, Injector, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { map, switchMap } from 'rxjs/operators';
import { ColumnFormat, ColumnInfo } from '../../../components/at-grid/column-info';
import { FilterInfo } from '../../../components/at-grid/filter-info';
import { CmmsWo } from '../../../entities/cmms/cmms-wo';
import { EntityName } from '../../../entities/entity-name';
import { CancelFormDecorator } from '../../../lib/cancel-form-decorator';
import { IListComponent } from '../../../lib/i-list-component';
import { IReactiveForm } from '../../../lib/i-reactive-form';
import { InvalidControlFormDecorator } from '../../../lib/invalid-control-form-decorator';
import { LifecycleComponent } from '../../../lib/lifecycle-component';
import { ReactiveFormDecorator } from '../../../lib/reactive-form-decorator';
import { ServiceProvider } from '../../../services/service-provider';
import { CommonLib } from '../../../lib/common-lib';
import { QueryPmAnalisys } from '../../../entities/query/query-pm-analisys';
@Component({
  templateUrl: 'query-pm-analisys.component.html'
})
@ReactiveFormDecorator()
@CancelFormDecorator()
@InvalidControlFormDecorator()
export class QueryPmAnalisysComponent extends LifecycleComponent implements IListComponent<CmmsWo>, OnInit, IReactiveForm {

  formGroup = new FormGroup({
  });

  changed = false;

  constructor(public injector: Injector) {
    super();
  }

  positions: any[] = [];

  gridMetaData: ColumnInfo[] = [
    new ColumnInfo('SERIAL_NUMBER', 'SERIAL_NUMBER', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('DESCRIPTIVE_TEXT', 'DESCRIPTIVE_TEXT', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('AREA', 'AREA', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('SERIAL_NUMBER_1', 'SERIAL_NUMBER_1', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('PM_NUM', 'PM_NUM', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('DAY_INTERVAL', 'DAY_INTERVAL', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('SCHEDULED_START_DATE', 'SCHEDULED_START_DATE', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('DESCRIPTION', 'DESCRIPTION', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('PM_NAME', 'PM_NAME', true, new FilterInfo(''), ColumnFormat.Default, false),
  ];

  //SERIAL_NUMBER, DESCRIPTIVE_TEXT, AREA, SERIAL_NUMBER_1, PM_NUM, DAY_INTERVAL, SCHEDULED_START_DATE, DESCRIPTION, PM_NAME

  newItem() {
    throw new Error('Not implemented');
  }
  selectRow(entity) {
  }
  onInit(): void {
    this.positions = [];
  }

  runQuery() {
    let serviceProvider = this.injector.get(ServiceProvider);
    serviceProvider.getEntityListUrl<QueryPmAnalisys>(`query_pm_analisys`)
      .pipe(
        map((entities: QueryPmAnalisys[]) => {
          return entities.map(x => serviceProvider.loadRawData(x, EntityName.pm_analisys));
        })
      )
      .subscribe(
        (positions) => {
          this.positions = positions;
          this.acceptChanges();
        }
      );
  }

  acceptChanges(): void {
    throw new Error('Not implemented');
  }
  goBack(): void {
    throw new Error('Not implemented');
  }
  getChanged(): boolean {
    throw new Error('Not implemented');
  }

  cancel() {
    throw new Error(`Not implemented`);
  }
  onSubmit() {
  }
  invalidControlClass(controlName: string) {
    throw new Error('Not implemented');
  }

  createCsv() {
    //SERIAL_NUMBER, DESCRIPTIVE_TEXT, AREA, SERIAL_NUMBER_1, PM_NUM, DAY_INTERVAL, SCHEDULED_START_DATE, DESCRIPTION, PM_NAME
    let csvContent = 'SERIAL_NUMBER,DESCRIPTIVE_TEXT,AREA,SERIAL_NUMBER_1,PM_NUM,DAY_INTERVAL,SCHEDULED_START_DATE,DESCRIPTION,PM_NAME\r\n';
    csvContent += this.positions.map(e => {
      return `${e['SERIAL_NUMBER'] ? e['SERIAL_NUMBER'] : ''},`+
      `${e['DESCRIPTIVE_TEXT'] ? e['DESCRIPTIVE_TEXT'] : ''},`+
      `${e['AREA'] ? e['AREA'] : ''},`+
      `${e['SERIAL_NUMBER_1'] ? e['SERIAL_NUMBER_1'] : ''},`+
      `${e['PM_NUM'] ? e['PM_NUM'] : ''},`+
      `${e['DAY_INTERVAL'] ? e['DAY_INTERVAL'] : '0'},`+
      `${e['SCHEDULED_START_DATE'] ? CommonLib.dateToShortString(e['SCHEDULED_START_DATE']) : ''},`+
      `${e['DESCRIPTION'] ? e['DESCRIPTION'] : ''},`+
      `${e['PM_NAME'] ? e['PM_NAME'] : ''}`+
      ``;
      // return `${e.activity ? e.activity : ''},${e.attribute1 ? e.attribute1 : ''},${e.contract_line ? e.contract_line : ''},${e.department ? e.department : ''},${e.description ? e.description : ''},${e.qty ? e.qty : ''},${e.unit_rate ? e.unit_rate : ''},${e.wip_accounting_class ? e.wip_accounting_class : ''}`;
    }).join('\r\n');
    let blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    if ((<any>navigator).msSaveBlob) { // IE 10+
        (<any>navigator).msSaveBlob(blob, `pm_analisys_${new Date().toLocaleDateString()}.csv`);
    } else {
        let link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            let url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", `pm_analisys_${new Date().toLocaleDateString()}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }

  }

}
