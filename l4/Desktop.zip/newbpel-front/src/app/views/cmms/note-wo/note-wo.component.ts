import { Component, EventEmitter, Injector, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormDecorator } from '../../../lib/reactive-form-decorator';
import { IReactiveForm } from '../../../lib/i-reactive-form';
import { InvalidControlFormDecorator } from '../../../lib/invalid-control-form-decorator';
import { LifecycleComponent } from '../../../lib/lifecycle-component';

@Component({
  templateUrl: 'note-wo.component.html'
})
@ReactiveFormDecorator()
@InvalidControlFormDecorator()
export class NoteWoComponent extends LifecycleComponent implements IReactiveForm, OnInit {

  formGroup = new FormGroup({
    text: new FormControl('', Validators.required),
  });

  private _text: string;

  @Input()
  set text(value: string) {
    this._text = value;
    let patchValue = <any>{ text: this._text };

    this.formGroup.patchValue(patchValue);
  };

  @Output()
  submit = new EventEmitter<string>();

  changed = false;

  constructor(public injector: Injector) {
    super();
  }

  acceptChanges(): void {
    throw new Error('Not implemented');
  }
  goBack(): void {
    throw new Error('Not implemented');
  }
  getChanged(): boolean {
    throw new Error('Not implemented');
  }

  cancel() {
    this.submit.next(null);
  }
  onSubmit() {
    this._text = this.formGroup.getRawValue().text;
    this.submit.next(this._text);
  }
  invalidControlClass(controlName: string) {
    throw new Error('Not implemented');
  }
  isExistsEntity() {
    throw new Error('Not implemented');
  }
}
