import { Component, EventEmitter, Injector, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CancelFormDecorator } from '../../../lib/cancel-form-decorator';
import { IReactiveForm } from '../../../lib/i-reactive-form';
import { InvalidControlFormDecorator } from '../../../lib/invalid-control-form-decorator';
import { LifecycleComponent } from '../../../lib/lifecycle-component';
import { ReactiveFormDecorator } from '../../../lib/reactive-form-decorator';
import { CommonLib } from '../../../lib/common-lib';

@Component({
  templateUrl: 'query-wo-statistic-param.component.html',
  selector: 'query-wo-statistic-param'
})
@ReactiveFormDecorator()
@CancelFormDecorator()
@InvalidControlFormDecorator()
export class QueryWOStatisticParamComponent extends LifecycleComponent implements OnInit, IReactiveForm {

  @Output()
  runQuery = new EventEmitter<{dt_start: Date, dt_end: Date}>();

  formGroup = new FormGroup({
    dt_start: new FormControl(CommonLib.formatDate(new Date(new Date().getFullYear(), new Date().getMonth() - 1, 27)), Validators.required),
    dt_end: new FormControl(CommonLib.formatDate(new Date(new Date().getFullYear(), new Date().getMonth(), 26)), Validators.required),
  });

  changed = true;

  constructor(public injector: Injector) {
    super();
  }

  newItem() {
    throw new Error('Not implemented');
  }

  onInit(): void {
  }


  acceptChanges(): void {
    throw new Error('Not implemented');
  }
  goBack(): void {
    throw new Error('Not implemented');
  }
  getChanged(): boolean {
    throw new Error('Not implemented');
  }

  cancel() {
    throw new Error(`Not implemented`);
  }
  onSubmit() {
    // throw new Error(`Not implemented`);
  }
  onSubmitRunQuery() {
    this.runQuery.next({dt_start: new Date(Date.parse(this.formGroup.value['dt_start'])), dt_end: new Date(Date.parse(this.formGroup.value['dt_end']))});
  }
  invalidControlClass(controlName: string) {
    throw new Error('Not implemented');
  }

}
