import { Component, Injector, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { map, switchMap } from 'rxjs/operators';
import { ColumnFormat, ColumnInfo } from '../../../components/at-grid/column-info';
import { FilterInfo } from '../../../components/at-grid/filter-info';
import { EntityName } from '../../../entities/entity-name';
import { CancelFormDecorator } from '../../../lib/cancel-form-decorator';
import { IListComponent } from '../../../lib/i-list-component';
import { IReactiveForm } from '../../../lib/i-reactive-form';
import { InvalidControlFormDecorator } from '../../../lib/invalid-control-form-decorator';
import { LifecycleComponent } from '../../../lib/lifecycle-component';
import { ReactiveFormDecorator } from '../../../lib/reactive-form-decorator';
import { ServiceProvider } from '../../../services/service-provider';
import { CommonLib } from '../../../lib/common-lib';
import { QueryRouteByAsset } from '../../../entities/query/query-route-by-asset';
@Component({
  templateUrl: 'query-route-by-asset.component.html'
})
@ReactiveFormDecorator()
@CancelFormDecorator()
@InvalidControlFormDecorator()
export class QueryRouteByAssetComponent extends LifecycleComponent implements IListComponent<QueryRouteByAsset>, OnInit, IReactiveForm {

  formGroup = new FormGroup({
  });

  changed = false;

  constructor(public injector: Injector) {
    super();
  }

  positions: any[] = [];

  /**
  Route_ID,
  Route_Number,
  Start_Date,
  End_Date,
  Asset_ID,
  Asset_Number,
  Asset_Group
  */
  gridMetaData: ColumnInfo[] = [
    new ColumnInfo('Route_ID', 'Route_ID', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('Route_Number', 'Route_Number', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('Start_Date', 'Start_Date', true, new FilterInfo(''), ColumnFormat.Date, false),
    new ColumnInfo('End_Date', 'End_Date', true, new FilterInfo(''), ColumnFormat.Date, false),
    new ColumnInfo('Asset_ID', 'Asset_ID', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('Asset_Number', 'Asset_Number', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('Asset_Group', 'Asset_Group', true, new FilterInfo(''), ColumnFormat.Default, false),
  ];

  newItem() {
    throw new Error('Not implemented');
  }
  selectRow(entity) {
  }
  onInit(): void {
    this.positions = [];
  }

  runQuery(param: { name: string }) {
    let serviceProvider = this.injector.get(ServiceProvider);
    serviceProvider.getEntityListUrl<QueryRouteByAsset>(`route_by_asset/${param.name}`)
      .pipe(
        map((entities: QueryRouteByAsset[]) => {
          return entities.map(x => serviceProvider.loadRawData(x, EntityName.route_by_asset));
        })
      )
      .subscribe(
        (positions) => {
          this.positions = positions;
          this.acceptChanges();
        }
      );
  }

  acceptChanges(): void {
    throw new Error('Not implemented');
  }
  goBack(): void {
    throw new Error('Not implemented');
  }
  getChanged(): boolean {
    throw new Error('Not implemented');
  }

  cancel() {
    throw new Error(`Not implemented`);
  }
  onSubmit() {
  }
  invalidControlClass(controlName: string) {
    throw new Error('Not implemented');
  }

  createCsv() {
    let csvContent = 'Route_ID,Route_Number,Start_Date,End_Date,Asset_ID,Asset_Number,Asset_Group\r\n';
    csvContent += this.positions.map(e => {
      return `${e['Route_ID'] ? e['Route_ID'] : ''},`+
      `${e['Route_Number'] ? e['Route_Number'] : ''},`+
      `${e['Start_Date'] ? CommonLib.dateToShortString(e['Start_Date']) : ''},`+
      `${e['End_Date'] ? CommonLib.dateToShortString(e['End_Date']) : ''},`+
      `${e['Asset_ID'] ? e['Asset_ID'] : ''},`+
      `${e['Asset_Number'] ? e['Asset_Number'] : ''},`+
      `${e['Asset_Group'] ? e['Asset_Group'] : ''}`+
      ``;
    }).join('\r\n');
    let blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    if ((<any>navigator).msSaveBlob) { // IE 10+
        (<any>navigator).msSaveBlob(blob, `route_by_asset_${new Date().toLocaleDateString()}.csv`);
    } else {
        let link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            let url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", `route_by_asset_${new Date().toLocaleDateString()}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }

  }

}
