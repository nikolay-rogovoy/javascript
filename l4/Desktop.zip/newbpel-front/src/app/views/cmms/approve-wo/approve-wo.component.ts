import { Component, Injector, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { concatMap, filter, map, reduce, switchMap } from 'rxjs/operators';
import { ColumnFormat, ColumnInfo } from '../../../components/at-grid/column-info';
import { FilterInfo } from '../../../components/at-grid/filter-info';
import { EntityName } from '../../../entities/entity-name';
import { CancelFormDecorator } from '../../../lib/cancel-form-decorator';
import { IListComponent } from '../../../lib/i-list-component';
import { IReactiveForm } from '../../../lib/i-reactive-form';
import { InvalidControlFormDecorator } from '../../../lib/invalid-control-form-decorator';
import { LifecycleComponent } from '../../../lib/lifecycle-component';
import { ReactiveFormDecorator } from '../../../lib/reactive-form-decorator';
import { ServiceProvider } from '../../../services/service-provider';
import { CommonLib } from '../../../lib/common-lib';
import { ApproveWo } from '../../../entities/query/approve-wo';
import { TemplateProviderComponent } from '../../../lib/template-provider-component/template-provider-component';
import { from, of } from 'rxjs';
import { AdminLib } from '../../../lib/admin-lib';
import { ModalContainerService } from '../../../components/modal-container-module/modal-container-service';
import { NoteWoComponent } from '../note-wo/note-wo.component';
import { NoteWoModalContainerStrategy } from '../../../components/modal-container-module/strategy/note-wo-modal-container-strategy';
import { NotificationService } from '../../../services/notification-service';
import { IUserDep } from '../../../interfaces/i-user-dep';
import { NoteDateWoComponent } from '../note-date-wo/note-date-wo.component';
import { NoteDateWoModalContainerStrategy } from '../../../components/modal-container-module/strategy/note-date-wo-modal-container-strategy';
@Component({
  templateUrl: 'approve-wo.component.html'
})
@ReactiveFormDecorator()
@CancelFormDecorator()
@InvalidControlFormDecorator()
export class ApproveWoComponent extends LifecycleComponent implements IListComponent<ApproveWo>, OnInit, IReactiveForm {

  formGroup = new FormGroup({
  });

  changed = false;

  constructor(public injector: Injector) {
    super();
  }

  /***/
  @ViewChild(TemplateProviderComponent, { static: true })
  templateProvider: TemplateProviderComponent;

  positions: any[] = [];

  total_sm = 0;
  total_count = 0;

  param: { dt: Date, everythingExceptGenerators: boolean, generatorsOnly: boolean };

  isSupervisor = false;
  isIngPlaner = false;
  /**
  wip_entity_id
  order_num
  work_order_no
  work_order_status_pending
  work_order_type
  description
  completion_date
  scheduled_start_date
  scheduled_completion_date
  asset_number
  asset_description
  activity
  wip_accounting_class
  qty
  unit_rate
  sm
  */
  gridMetaData: ColumnInfo[] = [
    new ColumnInfo('order_num', 'Order', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('work_order_no', 'WO number', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('work_order_status_pending', 'WO status', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('description', 'Description', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('activity', 'Activity', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('user_info', 'Info', true, new FilterInfo(''), ColumnFormat.Default, false),
    // new ColumnInfo('completion_date', 'Completion', true, new FilterInfo(''), ColumnFormat.Date, false),
    new ColumnInfo('scheduled_start_date', 'Scheduled Start', true, new FilterInfo(''), ColumnFormat.Date, false),
    new ColumnInfo('asset_number', 'Asset Number', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('asset_description', 'Asset Description', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('qty', 'Qty', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('unit_rate', 'Unit Rate', true, new FilterInfo(''), ColumnFormat.Currency, false),
    new ColumnInfo('sm', 'Sm', true, new FilterInfo(''), ColumnFormat.Currency, false),
    new ColumnInfo('actions', 'Actions', true, new FilterInfo(''), ColumnFormat.Template, false),
  ];

  /***/
  getAction(position: any, dep: IUserDep) {
    let isSupervisor = dep.posts.find(x => x.idpost === 1 || x.idpost === 2) != null;
    let isIngPlaner = dep.posts.find(x => x.idpost === 1 || x.idpost === 3) != null;

    let showCancel = false;
    if(isSupervisor) {
      showCancel = (position.work_order_status_pending.indexOf('Release') !== -1 || position.work_order_status_pending.indexOf('On Hold') !== -1);
    } else {
      showCancel = (position.work_order_status_pending.indexOf('Release') !== -1 || position.work_order_status_pending.indexOf('Approve') !== -1 || position.work_order_status_pending.indexOf('On Hold') !== -1);
    }
    let showPostpone = (position.work_order_status_pending.indexOf('Release') !== -1);
    let showRelease = false;
    if(isSupervisor) {
      showRelease = (position.work_order_status_pending.indexOf('Cancel') !== -1 || position.work_order_status_pending.indexOf('On Hold') !== -1);
    } else {
      showRelease = (position.work_order_status_pending.indexOf('Cancel') !== -1 || position.work_order_status_pending.indexOf('Approve') !== -1 || position.work_order_status_pending.indexOf('On Hold') !== -1);
    }
    let showApproved = (isIngPlaner) && (position.work_order_status_pending.indexOf('Release') !== -1 || position.work_order_status_pending.indexOf('Printed') !== -1);
    let showPrinted = isIngPlaner && (position.work_order_status_pending.indexOf('Approve') !== -1);
    return {
      template: this.templateProvider.gridButtons,
      context: {
        data: {
          buttons: [
            showCancel ? {
              click: this.cancelWO.bind(this),
              item: { entity: position },
              css: { 'btn-danger': true },
              caption: 'Cancel',
              content: 'content_copy',
              isMaterialIcon: true,
              disabled: false,
            } : null,
            showPostpone ? {
              click: this.postponeWO.bind(this),
              item: { entity: position },
              css: { 'btn-warning': true },
              caption: 'Postpone',
              content: 'content_copy',
              isMaterialIcon: true,
              disabled: false,
            } : null,
            showRelease ? {
              click: this.releaseWO.bind(this),
              item: { entity: position },
              css: { 'btn-info': true },
              caption: 'Release',
              content: 'delete',
              isMaterialIcon: true,
              disabled: false,
            } : null,
            showApproved ? {
              click: this.approvedWO.bind(this),
              item: { entity: position },
              css: { 'btn-success': true },
              caption: 'Approved',
              content: 'delete',
              isMaterialIcon: true,
              disabled: false,
            } : null,
            showPrinted ? {
              click: this.printedWO.bind(this),
              item: { entity: position },
              css: { 'btn-dark': true },
              caption: 'Printed',
              content: 'delete',
              isMaterialIcon: true,
              disabled: false,
            } : null,
          ].filter(x => x),
          content: ''
        }
      }
    };
  }

  postponeWO(entity: { entity: ApproveWo }) {
    this.injector.get(ModalContainerService).show({
      caption: 'Postpone WO form',
      style: 'primary',
      ctor: NoteDateWoComponent,
      modalContainerStrategy: new NoteDateWoModalContainerStrategy(entity.entity.user_text, new Date(Date.parse(<any>entity.entity.scheduled_start_date)))
    })
      .pipe(
        switchMap((result: { text: string, dt: Date }) => {
          if(result != null)
          {
            return this.injector.get(ServiceProvider).postRawData('set_wo_status', { status: 'postpone', id: entity.entity.wip_entity_id })
              .pipe(
                switchMap(() => {
                  return this.injector.get(ServiceProvider).postRawData('set_wo_user_text', { user_text: result.text, id: entity.entity.wip_entity_id });
                }),
                switchMap(() => {
                  return this.injector.get(ServiceProvider).postRawData('set_wo_start_date', { dt: result.dt, id: entity.entity.wip_entity_id });
                }),
              );
          } else {
            return of({});
          }
        })
      )
      .subscribe(() => {
        if (this.param) {
          this.runQuery(this.param);
        }
      });
  }

  cancelWO(entity: { entity: ApproveWo }) {
    this.injector.get(ModalContainerService).show({
      caption: 'Postpone WO form',
      style: 'primary',
      ctor: NoteWoComponent,
      modalContainerStrategy: new NoteWoModalContainerStrategy(entity.entity.user_text)
    })
      .pipe(
        switchMap((text: string) => {
          if(text != null) {
            return this.injector.get(ServiceProvider).postRawData('set_wo_status', { status: 'cancel', id: entity.entity.wip_entity_id })
              .pipe(
                switchMap(() => {
                  return this.injector.get(ServiceProvider).postRawData('set_wo_user_text', { user_text: text, id: entity.entity.wip_entity_id });
                })
              );
          } else {
            return of({});
          }
        })
      )
      .subscribe(() => {
        if (this.param) {
          this.runQuery(this.param);
        }
      });
  }

  releaseWO(entity) {
    this.injector.get(ServiceProvider).postRawData('set_wo_status', { status: 'release', id: entity.entity.wip_entity_id })
      .subscribe(() => {
        if (this.param) {
          this.runQuery(this.param);
        }
      });
  }

  printedWO(entity) {
    this.injector.get(ServiceProvider).postRawData('set_wo_status', { status: 'printed', id: entity.entity.wip_entity_id })
      .subscribe(() => {
        if (this.param) {
          this.runQuery(this.param);
        }
      });
  }

  approveAllReleased() {
    let releasedWO = this.positions.filter(x => x.work_order_status_pending === 'Released');
    if (releasedWO.length) {
      from(releasedWO)
        .pipe(
          concatMap((entity) => {
            return this.injector.get(ServiceProvider).postRawData('set_wo_status', { status: 'approved', id: entity.wip_entity_id });
          }),
          reduce((acc, val) => {
            acc.push(val);
            return acc;
          }, [])
        )
        .subscribe(() => {
          if (this.param) {
            this.runQuery(this.param);
          }
        });
    }
  }

  printApproved(param: { dt: Date, everythingExceptGenerators: boolean, generatorsOnly: boolean }) {
    let head = [
      {
        total_sm_str: this.positions.reduce((acc, val) => {
          acc += val.sm;
          return acc;
        }, 0).toFixed(2),
        user: AdminLib.getMyUser().name,
        dt_str: CommonLib.formatDate(param.dt),
      }
    ];
    this.injector.get(ServiceProvider).postRawData('report_approve', {
      ...param,
      positions: this.positions.map(position => {
        let newPos = { ...position };
        delete newPos.actions;
        newPos.unit_rate_str = newPos.unit_rate?.toFixed(2);
        newPos.sm_str = newPos.sm?.toFixed(2);
        newPos.scheduled_start_date_str = newPos.scheduled_start_date ? CommonLib.dateToShortString(new Date(Date.parse(newPos.scheduled_start_date))) : null;
        newPos.scheduled_completion_date_str = newPos.scheduled_completion_date ? CommonLib.dateToShortString(new Date(Date.parse(newPos.scheduled_completion_date))) : null;
        return newPos;
      }),
      head
    })
      .subscribe((response: { result: any }) => {
        if (this.param) {
          this.runQuery(this.param);
        }
        const byteCharacters = atob(response.result);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });

        if ((<any>navigator).msSaveBlob) { // IE 10+
          (<any>navigator).msSaveBlob(blob, `approve_wo_${new Date().toLocaleDateString()}.pdf`);
        } else {
          let link = document.createElement("a");
          if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            let url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", `approve_wo_${new Date().toLocaleDateString()}.pdf`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          }
        }

      });
  }

  approvedWO(entity) {
    this.injector.get(ServiceProvider).postRawData('set_wo_status', { status: 'approved', id: entity.entity.wip_entity_id })
      .subscribe(() => {
        if (this.param) {
          this.runQuery(this.param);
        }
      });
  }

  newItem() {
    throw new Error('Not implemented');
  }
  selectRow(entity) {
  }
  onInit(): void {
    this.positions = [];

    this.injector.get(NotificationService).dep
      .pipe(
        filter(dep => dep != null),
        switchMap((dep: IUserDep) => {
          this.isSupervisor = dep.posts.find(x => x.idpost === 1 || x.idpost === 2) != null;
          this.isIngPlaner = dep.posts.find(x => x.idpost === 1 || x.idpost === 3) != null;
          return of(dep);
        })
      ).subscribe();
  }
  runQuery(param: { dt: Date, everythingExceptGenerators: boolean, generatorsOnly: boolean }) {
    param.everythingExceptGenerators = true;
    param.generatorsOnly = true;
    this.param = param;
    let serviceProvider = this.injector.get(ServiceProvider);
    return this.injector.get(NotificationService).dep
      .pipe(
        filter(dep => dep != null),
        switchMap((dep: IUserDep) => {
          return serviceProvider.getEntityListUrl<ApproveWo>(`approve_wo_list/${CommonLib.formatDate(param.dt)}/${param.everythingExceptGenerators}/${param.generatorsOnly}`)
            .pipe(
              map((entities: ApproveWo[]) => {
                entities = entities.filter(x => 
                  (dep.iddep === 2 && x.activity.indexOf('ECL-HV') !== -1) //HVAC
                  || (dep.iddep === 3 && (x.activity.indexOf('ECL-EL') !== -1 || x.activity.indexOf('ECL-IN') !== -1)) //ELEC-INSTR
                  || (dep.iddep === 4 && (x.activity.indexOf('ECL-PL') !== -1)) //MECH
                  || dep.iddep === 1
                  );
                return entities.map(x => serviceProvider.loadRawData(x, EntityName.asset_by_route));
              }),
              map((entities: ApproveWo[]) => {
                entities = entities.map(x => {
                  return <ApproveWo>{ ...x, actions: this.getAction(x, dep) };
                });
                return entities;
              }),
            )
        })
      )
      .subscribe(
        (positions: ApproveWo[]) => {
          this.positions = positions;
          this.total_count = positions.length;
          let total_sm = positions.reduce((acc, val) => {
            acc += val.sm;
            return acc;
          }, 0);
          this.total_sm = Math.round(total_sm * 100) / 100;
          this.acceptChanges();
        }
      );
  }

  acceptChanges(): void {
    throw new Error('Not implemented');
  }
  goBack(): void {
    throw new Error('Not implemented');
  }
  getChanged(): boolean {
    throw new Error('Not implemented');
  }

  cancel() {
    throw new Error(`Not implemented`);
  }
  onSubmit() {
  }
  invalidControlClass(controlName: string) {
    throw new Error('Not implemented');
  }

  createCsv() {
    let csvContent = 'Route_ID,Route_Number,Start_Date,End_Date,Asset_ID,Asset_Number,Asset_Group\r\n';
    csvContent += this.positions.map(e => {
      return `${e['Route_ID'] ? e['Route_ID'] : ''},` +
        `${e['Route_Number'] ? e['Route_Number'] : ''},` +
        `${e['Start_Date'] ? CommonLib.dateToShortString(e['Start_Date']) : ''},` +
        `${e['End_Date'] ? CommonLib.dateToShortString(e['End_Date']) : ''},` +
        `${e['Asset_ID'] ? e['Asset_ID'] : ''},` +
        `${e['Asset_Number'] ? e['Asset_Number'] : ''},` +
        `${e['Asset_Group'] ? e['Asset_Group'] : ''}` +
        ``;
    }).join('\r\n');
    let blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    if ((<any>navigator).msSaveBlob) { // IE 10+
      (<any>navigator).msSaveBlob(blob, `approve_wo_${new Date().toLocaleDateString()}.csv`);
    } else {
      let link = document.createElement("a");
      if (link.download !== undefined) { // feature detection
        // Browsers that support HTML5 download attribute
        let url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", `approve_wo_${new Date().toLocaleDateString()}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }

  }

}
