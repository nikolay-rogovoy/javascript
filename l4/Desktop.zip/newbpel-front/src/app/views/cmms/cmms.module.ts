import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { AtGridModule } from '../../components/at-grid/at-grid-module';
import { TemplateProviderModule } from '../../lib/template-provider-component/template-provider-module';
import { ApproveWoParamComponent } from './approve-wo-param/approve-wo-param.component';
import { ApproveWoComponent } from './approve-wo/approve-wo.component';
import { CertificateWoEditComponent } from './certificate-wo-edit/certificate-wo-edit.component';
import { CertificateComponent } from './certificate/certificate.component';
import { CmmsRoutingModule } from './cmms-routing.module';
import { ConfirmWoComponent } from './confirm-wo/confirm-wo.component';
import { NoteDateWoComponent } from './note-date-wo/note-date-wo.component';
import { NoteWoComponent } from './note-wo/note-wo.component';
import { QueryAssetByRouteParamComponent } from './query-asset-by-route-param/query-asset-by-route-param.component';
import { QueryAssetByRouteComponent } from './query-asset-by-route/query-asset-by-route.component';
import { QueryPmAnalisysParamComponent } from './query-pm-analisys-param/query-pm-analisys-param.component';
import { QueryPmAnalisysComponent } from './query-pm-analisys/query-pm-analisys.component';
import { QueryPmNewParamComponent } from './query-pm-new-param/query-pm-new-param.component';
import { QueryPmNewComponent } from './query-pm-new/query-pm-new.component';
import { QueryRouteByAssetParamComponent } from './query-route-by-asset-param/query-route-by-asset-param.component';
import { QueryRouteByAssetComponent } from './query-route-by-asset/query-route-by-asset.component';
import { QueryWOStatisticParamComponent } from './query-wo-statistic-param/query-wo-statistic-param.component';
import { QueryWoStatisticComponent } from './query-wo-statistic/query-wo-statistic.component';
import { SearchPeriodComponent } from './search-period/search-period.component';
import { SearchWOComponent } from './search-wo/search-wo.component';

@NgModule({
  imports: [
    CommonModule,
    CmmsRoutingModule,
    AtGridModule,
    ReactiveFormsModule,
    TemplateProviderModule,
  ],
  declarations: [
    CertificateComponent,
    QueryWoStatisticComponent,
    QueryWOStatisticParamComponent,
    CertificateWoEditComponent,
    NoteDateWoComponent,
    NoteWoComponent,
    SearchWOComponent,
    SearchPeriodComponent,
    QueryPmAnalisysComponent,
    QueryPmAnalisysParamComponent,
    QueryPmNewComponent,
    QueryPmNewParamComponent,
    QueryAssetByRouteComponent,
    QueryAssetByRouteParamComponent,
    QueryRouteByAssetComponent,
    QueryRouteByAssetParamComponent,
    QueryWOStatisticParamComponent,
    ApproveWoComponent,
    ApproveWoParamComponent,
    ConfirmWoComponent,
  ],
  entryComponents: [
    CertificateWoEditComponent,
    NoteWoComponent,
    NoteDateWoComponent,
  ]
})
export class CmmsModule { }
