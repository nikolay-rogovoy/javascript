import { Component, EventEmitter, Injector, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CancelFormDecorator } from '../../../lib/cancel-form-decorator';
import { IReactiveForm } from '../../../lib/i-reactive-form';
import { InvalidControlFormDecorator } from '../../../lib/invalid-control-form-decorator';
import { LifecycleComponent } from '../../../lib/lifecycle-component';
import { ReactiveFormDecorator } from '../../../lib/reactive-form-decorator';

@Component({
  templateUrl: 'query-pm-new-param.component.html',
  selector: 'query-pm-new-param'
})
@ReactiveFormDecorator()
@CancelFormDecorator()
@InvalidControlFormDecorator()
export class QueryPmNewParamComponent extends LifecycleComponent implements OnInit, IReactiveForm {

  @Output()
  runQuery = new EventEmitter<void>();

  formGroup = new FormGroup({
  });

  changed = true;

  constructor(public injector: Injector) {
    super();
  }

  newItem() {
    throw new Error('Not implemented');
  }

  onInit(): void {
  }


  acceptChanges(): void {
    throw new Error('Not implemented');
  }
  goBack(): void {
    throw new Error('Not implemented');
  }
  getChanged(): boolean {
    throw new Error('Not implemented');
  }

  cancel() {
    throw new Error(`Not implemented`);
  }
  onSubmit() {
    // throw new Error(`Not implemented`);
  }
  onSubmitRunQuery() {
    this.runQuery.next();
  }
  invalidControlClass(controlName: string) {
    throw new Error('Not implemented');
  }

}
