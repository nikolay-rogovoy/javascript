import { Component, Injector, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { map, switchMap } from 'rxjs/operators';
import { ColumnFormat, ColumnInfo } from '../../../components/at-grid/column-info';
import { FilterInfo } from '../../../components/at-grid/filter-info';
import { ModalContainerService } from '../../../components/modal-container-module/modal-container-service';
import { CertificateWoEditModalContainerStrategy } from '../../../components/modal-container-module/strategy/certificate-wo-edit-modal-container-strategy';
import { CmmsWo } from '../../../entities/cmms/cmms-wo';
import { CmmsWoSum } from '../../../entities/cmms/cmms-wo-sum';
import { EntityName } from '../../../entities/entity-name';
import { IUserDep } from '../../../interfaces/i-user-dep';
import { CancelFormDecorator } from '../../../lib/cancel-form-decorator';
import { IListComponent } from '../../../lib/i-list-component';
import { IReactiveForm } from '../../../lib/i-reactive-form';
import { InvalidControlFormDecorator } from '../../../lib/invalid-control-form-decorator';
import { LifecycleComponent } from '../../../lib/lifecycle-component';
import { ReactiveFormDecorator } from '../../../lib/reactive-form-decorator';
import { NotificationService } from '../../../services/notification-service';
import { ServiceProvider } from '../../../services/service-provider';
import { CertificateWoEditComponent } from '../certificate-wo-edit/certificate-wo-edit.component';
import { CommonLib } from '../../../lib/common-lib';
@Component({
  templateUrl: 'certificate.component.html'
})
@ReactiveFormDecorator()
@CancelFormDecorator()
@InvalidControlFormDecorator()
export class CertificateComponent extends LifecycleComponent implements IListComponent<CmmsWo>, OnInit, IReactiveForm {

  formGroup = new FormGroup({
    dt_start: new FormControl(CommonLib.formatDate(new Date(new Date().getFullYear(), new Date().getMonth() - 1, 27)), Validators.required),
    dt_end: new FormControl(CommonLib.formatDate(new Date(new Date().getFullYear(), new Date().getMonth(), 26)), Validators.required),
  });

  changed = false;

  constructor(public injector: Injector) {
    super();
  }

  showWOList = true;
  showCertificate = false;

  positions: CmmsWo[] = [];
  positions2: CmmsWoSum[] = [];

  gridMetaData: ColumnInfo[] = [
    new ColumnInfo('work_order_no', 'Work Order No', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('attribute1', 'Contract', true, new FilterInfo(''), ColumnFormat.Default, false),
    // new ColumnInfo('work_order_type', 'work_order_type', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('attribute4', 'Complited by supervisor', true, new FilterInfo(''), ColumnFormat.Date, false),
    new ColumnInfo('asset_number', 'Asset Number', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('asset_description', 'Asset Description', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('department', 'Department', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('activity', 'Activity Number', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('wip_accounting_class', 'WIP Accounting Class', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('contract_line', 'Contract line', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('description', 'Description', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('qty', 'Qty', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('unit_rate', 'Unit rate', true, new FilterInfo(''), ColumnFormat.Default, false),
  ];

  gridMetaDataCert: ColumnInfo[] = [
    new ColumnInfo('attribute1', 'Contract', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('contract_line', 'Contract line', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('description', 'Work Description', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('wip_accounting_class', 'WIP Accounting Class', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('cost_center_description', 'Cost Center Description', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('qty', 'Qty', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('unit_rate', 'Unit Rate', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('activity', 'Activity', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('department', 'Department', true, new FilterInfo(''), ColumnFormat.Default, false),
  ];

  newItem() {
    throw new Error('Not implemented');
  }
  selectRow(entity) {
    // this.injector.get(Router).navigate([`${entityName}/${entity[entitiesMetadata.pkName]}`], { relativeTo: this.injector.get(ActivatedRoute).parent });
    this.injector.get(ModalContainerService).show({
      caption: 'Change WO form',
      style: 'primary',
      ctor: CertificateWoEditComponent,
      modalContainerStrategy: new CertificateWoEditModalContainerStrategy(entity)
    })
      .pipe(
        switchMap((cmmsWo: CmmsWo) => {
          return this.injector.get(NotificationService).dep.pipe(
            switchMap((dep: IUserDep) => {
              console.log(cmmsWo);
              return this.injector.get(ServiceProvider).postEntity(cmmsWo, dep.iddep, EntityName.cmms_wo);
            })
          );
        })
      )
      .subscribe(() => {
        console.log('post cmms_wo ok');
      },
      (error) => {
        console.error(error);
      });
  }
  onInit(): void {
    this.positions = [];
  }

  loadCmmsByPeriod(period: {dt_start: Date, dt_end: Date}) {
    let serviceProvider = this.injector.get(ServiceProvider);
    console.log(period);
    if(period.dt_end && period.dt_start){
      serviceProvider.getEntityListUrl<CmmsWo>(`certificate_wo/${CommonLib.formatDate2(period.dt_start)}/${CommonLib.formatDate2(period.dt_end)}`)
        .pipe(
          map((entities: CmmsWo[]) => {
            return entities.map(x => serviceProvider.loadRawData(x, EntityName.cmms_wo));;
          })
        )
        .subscribe(
          (positions) => {
            this.positions = positions;
            this.showWOList = true;
            this.showCertificate = false;
            this.acceptChanges();
          }
        );
    }
  }

  loadCmmsByWO(woName: string) {
    let serviceProvider = this.injector.get(ServiceProvider);
    serviceProvider.getEntityListUrl<CmmsWo>(`wo_by_name/${woName}`)
      .pipe(
        map((entities: CmmsWo[]) => {
          return entities.map(x => serviceProvider.loadRawData(x, EntityName.cmms_wo));;
        })
      )
      .subscribe(
        (positions) => {
          this.positions = positions;
          this.showWOList = true;
          this.showCertificate = false;
          this.acceptChanges();
        }
      );
  }

  acceptChanges(): void {
    throw new Error('Not implemented');
  }
  goBack(): void {
    throw new Error('Not implemented');
  }
  getChanged(): boolean {
    throw new Error('Not implemented');
  }

  cancel() {
    throw new Error(`Not implemented`);
  }
  onSubmit() {
  }
  invalidControlClass(controlName: string) {
    throw new Error('Not implemented');
  }

  loadCmmsCertificate(period: {dt_start: Date, dt_end: Date}) {
    console.log('loadCmmsCertificate', period);
    if(period.dt_end && period.dt_start){
    let serviceProvider = this.injector.get(ServiceProvider);
    serviceProvider.getEntityListUrl<CmmsWoSum>(`certificate_wo_sum/${CommonLib.formatDate2(period.dt_start)}/${CommonLib.formatDate2(period.dt_end)}`)
      .pipe(
        map((entities: CmmsWoSum[]) => {
          return entities.map(x => serviceProvider.loadRawData(x, EntityName.cmms_wo_sum));;
        })
      )
      .subscribe(
        (positions) => {
          this.positions2 = positions;
          this.showWOList = false;
          this.showCertificate = true;
          this.acceptChanges();
        }
      );
    }
  }

  searchByWoName(woName: string) {
    this.loadCmmsByWO(woName);
  }
  searchByPeriod(period: {dt_start: Date, dt_end: Date}) {
    this.loadCmmsByPeriod(period);
  }

  createCertificateCsv() {
    let csvContent = 'Contract,Contract Line,Work Description,WIP Accounting Class,Cost Center Description,QTY,Unit Rate,Amount,Activity,Department\r\n';
    csvContent += this.positions2.map(e => {
      return `${e.attribute1 ? e.attribute1 : ''},${e.contract_line ? e.contract_line : ''},${e.description ? e.description : ''},${e.wip_accounting_class ? e.wip_accounting_class : ''},${e.cost_center_description ? e.cost_center_description : ''},${e.qty ? e.qty : ''},${e.unit_rate ? e.unit_rate : ''},${e.qty && e.unit_rate? +e.qty * +e.unit_rate: 0},${e.activity ? e.activity : ''},${e.department ? e.department : ''}`;
      // return `${e.activity ? e.activity : ''},${e.attribute1 ? e.attribute1 : ''},${e.contract_line ? e.contract_line : ''},${e.department ? e.department : ''},${e.description ? e.description : ''},${e.qty ? e.qty : ''},${e.unit_rate ? e.unit_rate : ''},${e.wip_accounting_class ? e.wip_accounting_class : ''}`;
    }).join('\r\n');
    let blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    if ((<any>navigator).msSaveBlob) { // IE 10+
        (<any>navigator).msSaveBlob(blob, `cert_${new Date().toLocaleDateString()}.csv`);
    } else {
        let link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            let url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", `cert_${new Date().toLocaleDateString()}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }
  }

  createWoListCsv() {
    let csvContent = 'Work Order No,Work Order Type,Contract,Date,Asset Number,Asset Description,Department,Activity Number,WIP Accounting Class,Contract Line,Activity Description,QTY,Unit Rate,Amount,Comments and Correct QTY\r\n';//'data:text/csv;charset=utf-8,'
    csvContent += this.positions.map(e => {
      return `${e.work_order_no ? e.work_order_no : ''},${e.work_order_type ? e.work_order_type : ''},${e.attribute1 ? e.attribute1 : ''},${e.attribute4 ? CommonLib.dateToShortString(e.attribute4) : ''},`+
      `${e.asset_number ? e.asset_number : ''},${e.asset_description ? e.asset_description.replaceAll(',', ';') : ''},${e.department ? e.department : ''},`+
      `${e.activity ? e.activity : ''},${e.wip_accounting_class ? e.wip_accounting_class : ''},${e.contract_line ? e.contract_line : ''},`+
      `${e.description ? e.description.replaceAll(',', ';') : ''},${e.qty ? e.qty : ''},${e.unit_rate ? e.unit_rate : ''},${e.qty && e.unit_rate ? +e.qty * +e.unit_rate : 0},`;
      // return `${e.activity ? e.activity : ''},${e.asset_description ? e.asset_description.replaceAll(',', ';') : ''},${e.asset_number ? e.asset_number : ''},${e.attribute1 ? e.attribute1 : ''},${e.attribute4 ? e.attribute4 : ''},${e.contract_line ? e.contract_line : ''},${e.department ? e.department : ''},${e.description ? e.description : ''},${e.qty ? e.qty : ''},${e.unit_rate ? e.unit_rate : ''},${e.wip_accounting_class ? e.wip_accounting_class : ''},${e.work_order_no ? e.work_order_no : ''},${e.work_order_type ? e.work_order_type : ''}`;
    }).join('\r\n');
    let blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    if ((<any>navigator).msSaveBlob) { // IE 10+
        (<any>navigator).msSaveBlob(blob, `wo_list_${new Date().toLocaleDateString()}.csv`);
    } else {
        let link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            let url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", `wo_list_${new Date().toLocaleDateString()}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }
  }
}
