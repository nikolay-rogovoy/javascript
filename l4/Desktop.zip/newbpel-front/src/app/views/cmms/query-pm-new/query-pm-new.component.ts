import { Component, Injector, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { map, switchMap } from 'rxjs/operators';
import { ColumnFormat, ColumnInfo } from '../../../components/at-grid/column-info';
import { FilterInfo } from '../../../components/at-grid/filter-info';
import { CmmsWo } from '../../../entities/cmms/cmms-wo';
import { EntityName } from '../../../entities/entity-name';
import { CancelFormDecorator } from '../../../lib/cancel-form-decorator';
import { IListComponent } from '../../../lib/i-list-component';
import { IReactiveForm } from '../../../lib/i-reactive-form';
import { InvalidControlFormDecorator } from '../../../lib/invalid-control-form-decorator';
import { LifecycleComponent } from '../../../lib/lifecycle-component';
import { ReactiveFormDecorator } from '../../../lib/reactive-form-decorator';
import { ServiceProvider } from '../../../services/service-provider';
import { CommonLib } from '../../../lib/common-lib';
import { QueryPmNew } from '../../../entities/query/query-pm-new';
@Component({
  templateUrl: 'query-pm-new.component.html'
})
@ReactiveFormDecorator()
@CancelFormDecorator()
@InvalidControlFormDecorator()
export class QueryPmNewComponent extends LifecycleComponent implements IListComponent<QueryPmNew>, OnInit, IReactiveForm {

  formGroup = new FormGroup({
  });

  changed = false;

  constructor(public injector: Injector) {
    super();
  }

  positions: any[] = [];

  gridMetaData: ColumnInfo[] = [
    new ColumnInfo('AREA', 'AREA', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('SERIAL_NUMBER', 'SERIAL_NUMBER', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('DESCRIPTIVE_TEXT', 'DESCRIPTIVE_TEXT', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('ACCOUNTING_CLASS_CODE', 'ACCOUNTING_CLASS_CODE', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('OWNING_DEPARTMENT', 'OWNING_DEPARTMENT', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('NETWORK_SERIAL_NUMBER', 'NETWORK_SERIAL_NUMBER', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('NAME', 'NAME', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('INTERVAL_DAY', 'INTERVAL_DAY', true, new FilterInfo(''), ColumnFormat.Number, false),
    new ColumnInfo('PLAN_NUM', 'PLAN_NUM', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('ACTIVITY_DESCRIPTION', 'ACTIVITY_DESCRIPTION', true, new FilterInfo(''), ColumnFormat.Default, false),
    new ColumnInfo('LAST_SERVICE_START_DATE', 'LAST_SERVICE_START_DATE', true, new FilterInfo(''), ColumnFormat.Date, false),
    new ColumnInfo('ESTIM_NEXT_DATE', 'ESTIM_NEXT_DATE', true, new FilterInfo(''), ColumnFormat.Date, false),
    new ColumnInfo('NEXT_DATE', 'NEXT_DATE', true, new FilterInfo(''), ColumnFormat.Date, false),
  ];

  newItem() {
    throw new Error('Not implemented');
  }
  selectRow(entity) {
  }
  onInit(): void {
    this.positions = [];
  }

  runQuery() {
    let serviceProvider = this.injector.get(ServiceProvider);
    serviceProvider.getEntityListUrl<QueryPmNew>(`query_pm_new`)
      .pipe(
        map((entities: QueryPmNew[]) => {
          return entities.map(x => serviceProvider.loadRawData(x, EntityName.pm_new));
        })
      )
      .subscribe(
        (positions) => {
          this.positions = positions;
          this.acceptChanges();
        }
      );
  }

  acceptChanges(): void {
    throw new Error('Not implemented');
  }
  goBack(): void {
    throw new Error('Not implemented');
  }
  getChanged(): boolean {
    throw new Error('Not implemented');
  }

  cancel() {
    throw new Error(`Not implemented`);
  }
  onSubmit() {
  }
  invalidControlClass(controlName: string) {
    throw new Error('Not implemented');
  }

  createCsv() {
    let csvContent = 'AREA,SERIAL_NUMBER,DESCRIPTIVE_TEXT,ACCOUNTING_CLASS_CODE,OWNING_DEPARTMENT,NETWORK_SERIAL_NUMBER,NAME,INTERVAL_DAY,PLAN_NUM,ACTIVITY_DESCRIPTION,LAST_SERVICE_START_DATE,ESTIM_NEXT_DATE,NEXT_DATE\r\n';
    csvContent += this.positions.map(e => {
      return `${e['AREA'] ? e['AREA'] : ''},`+
      `${e['SERIAL_NUMBER'] ? e['SERIAL_NUMBER'] : ''},`+
      `${e['DESCRIPTIVE_TEXT'] ? e['DESCRIPTIVE_TEXT'] : ''},`+
      `${e['ACCOUNTING_CLASS_CODE'] ? e['ACCOUNTING_CLASS_CODE'] : ''},`+
      `${e['OWNING_DEPARTMENT'] ? e['OWNING_DEPARTMENT'] : ''},`+
      `${e['NETWORK_SERIAL_NUMBER'] ? e['NETWORK_SERIAL_NUMBER'] : ''},`+
      `${e['NAME'] ? e['NAME'] : ''},`+
      `${e['INTERVAL_DAY'] ? e['INTERVAL_DAY'] : '0'},`+
      `${e['PLAN_NUM'] ? e['PLAN_NUM'] : ''},`+
      `${e['ACTIVITY_DESCRIPTION'] ? e['ACTIVITY_DESCRIPTION'] : ''},`+
      `${e['LAST_SERVICE_START_DATE'] ? CommonLib.dateToShortString(e['LAST_SERVICE_START_DATE']) : ''},`+
      `${e['ESTIM_NEXT_DATE'] ? CommonLib.dateToShortString(e['ESTIM_NEXT_DATE']) : ''},`+
      `${e['NEXT_DATE'] ? CommonLib.dateToShortString(e['NEXT_DATE']) : ''}`+
      ``;
    }).join('\r\n');
    let blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    if ((<any>navigator).msSaveBlob) { // IE 10+
        (<any>navigator).msSaveBlob(blob, `pm_new_${new Date().toLocaleDateString()}.csv`);
    } else {
        let link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            let url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", `pm_new_${new Date().toLocaleDateString()}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }

  }

}
