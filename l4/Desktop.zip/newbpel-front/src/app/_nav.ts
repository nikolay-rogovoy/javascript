import { INavData } from '@coreui/angular';

export const navItems: INavData[] = [
  // {
  //   name: 'Dashboard',
  //   url: '/dashboard',
  //   icon: 'icon-speedometer',
  // },
  {
    title: true,
    name: 'Work Orders'
  },
  { name: 'Certificate', url: '/cmms/certificate', icon: 'cil-diamond' },
  // { name: 'Confirm', url: '/cmms/confirm_wo', icon: 'cil-flip-to-front' },
  { name: 'Approve', url: '/cmms/approve_wo', icon: 'cil-flip-to-front' },

  {
    title: true,
    name: 'Queries'
  },
  { name: 'WO Statistic', url: '/cmms/wo_statistic', icon: 'cil-chart' },
  { name: 'PM Analisys', url: '/cmms/pm_analisys', icon: 'cil-chart-pie' },
  { name: 'PM New', url: '/cmms/pm_new', icon: 'cil-chart-line' },
  { name: 'Route by Asset', url: '/cmms/route_by_asset', icon: 'cil-flip-to-back' },
  { name: 'Asset by Route', url: '/cmms/asset_by_route', icon: 'cil-flip-to-front' },

  // {
  //   name: 'Queries',
  //   // url: '/cmms/certificate',
  //   icon: 'cil-menu',
  //   children: [
  //     { name: 'WO Statistic', url: '/cmms/wo_statistic', icon: 'cil-chart' },
  //     { name: 'PM Analisys', url: '/cmms/pm_analisys', icon: 'cil-chart-pie' },
  //     { name: 'PM New', url: '/cmms/pm_new', icon: 'cil-chart-line' },
  //     { name: 'Route by Asset', url: '/cmms/route_by_asset', icon: 'cil-flip-to-back' },
  //     { name: 'Asset by Route', url: '/cmms/asset_by_route', icon: 'cil-flip-to-front' },
  //     { name: 'Approve WO', url: '/cmms/approve_wo', icon: 'cil-flip-to-front' },
  //   ]
  // },
  // {
  //   name: 'System settings',
  //   url: '/theme/colors',
  //   icon: 'cil-settings',
  //   children: [
  //     {
  //       name: 'Departments',
  //       url: '/admin/deps',
  //       icon: 'icon-puzzle'
  //     }
  //   ]
  // }
];
