import { IMetadataTable } from '../metadata/i-metadata-table';

/***/
export interface IBPPost extends IMetadataTable {
}
